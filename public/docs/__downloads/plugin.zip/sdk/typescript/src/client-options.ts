import type { TokenProvider } from "./core/auth/credentials.js";
import type { CoreClientOptions } from "./core/client-options.js";
import { ServerEnvironment } from "./servers.js";

export type ClientOptions = SdkClientOptions & CoreClientOptions;

type SdkClientOptions = ServerOptions & {
  /** Secret key returned when the project is created. Lets the worker upload evidence. */
  readonly workerKey?: TokenProvider | undefined;
  /** Key held by the human verifier. Lets them read the queue and decide held cases. */
  readonly verifierKey?: TokenProvider | undefined;
  /** Optional key some servers require to create projects. */
  readonly organizerKey?: TokenProvider | undefined;
};

type ServerOptions =
  | {
      readonly serverEnvironment?: typeof ServerEnvironment.Production;
      /** Production: hosted demo (simulated payments, real AI reviewers) */
      readonly serverOptions?: {
        baseUrl?: string;
      };
    }
  | {
      readonly serverEnvironment: typeof ServerEnvironment.Environment2;
      /** Production: hosted demo (simulated payments, real AI reviewers) */
      readonly serverOptions?: {
        baseUrl?: string;
      };
    };
