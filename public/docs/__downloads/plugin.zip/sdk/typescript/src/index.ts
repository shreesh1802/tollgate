export { ProofPayApiClient } from "./client.js";
export type { ClientOptions } from "./client-options.js";

export type { TokenProvider } from "./core/auth/credentials.js";

export { ServerEnvironment } from "./servers.js";

export { Projects } from "./resources/projects.js";
export { Donations } from "./resources/donations.js";
export { Evidence } from "./resources/evidence.js";
export { Verification } from "./resources/verification.js";
export { Service } from "./resources/service.js";

export { apiConfigResponseSchema, type ApiConfigResponse } from "./models/api-config-response.js";
export { apiHealthResponseSchema, type ApiHealthResponse } from "./models/api-health-response.js";
export {
  apiProjectsAuditResponseSchema,
  type ApiProjectsAuditResponse,
} from "./models/api-projects-audit-response.js";
export {
  apiProjectsDonationsRequestSchema,
  type ApiProjectsDonationsRequest,
} from "./models/api-projects-donations-request.js";
export {
  apiProjectsDonationsResponseSchema,
  type ApiProjectsDonationsResponse,
} from "./models/api-projects-donations-response.js";
export { apiProjectsResponseSchema, type ApiProjectsResponse } from "./models/api-projects-response.js";
export { apiVerifyRequestSchema, type ApiVerifyRequest } from "./models/api-verify-request.js";
export { apiVerifyResponseSchema, type ApiVerifyResponse } from "./models/api-verify-response.js";
export { chainSchema, type Chain } from "./models/chain.js";
export { checkSchema, type Check } from "./models/check.js";
export { Decision, decisionSchema } from "./models/decision.js";
export { Decision1, decision1Schema } from "./models/decision1.js";
export { donationSchema, type Donation } from "./models/donation.js";
export { DonationStatus, donationStatusSchema } from "./models/donation-status.js";
export { errorSchema, type Error } from "./models/error.js";
export { errorErrorSchema, type ErrorError } from "./models/error-error.js";
export { Id, idSchema } from "./models/id.js";
export { Mode, modeSchema } from "./models/mode.js";
export { newProjectSchema, type NewProject } from "./models/new-project.js";
export { newStageSchema, type NewStage } from "./models/new-stage.js";
export { payoutSchema, type Payout } from "./models/payout.js";
export { projectSchema, type Project } from "./models/project.js";
export { projectSummarySchema, type ProjectSummary } from "./models/project-summary.js";
export { queueItemSchema, type QueueItem } from "./models/queue-item.js";
export { releaseSchema, type Release } from "./models/release.js";
export { reviewSchema, type Review } from "./models/review.js";
export { ReviewMode, reviewModeSchema } from "./models/review-mode.js";
export { siteSchema, type Site } from "./models/site.js";
export { stageSchema, type Stage } from "./models/stage.js";
export { stage1Schema, type Stage1 } from "./models/stage1.js";
export { StageStatus, stageStatusSchema } from "./models/stage-status.js";
export { Status, statusSchema } from "./models/status.js";
export { submissionSchema, type Submission } from "./models/submission.js";
export { submissionResultSchema, type SubmissionResult } from "./models/submission-result.js";
export { SubmissionStatus, submissionStatusSchema } from "./models/submission-status.js";
export { submissionSummarySchema, type SubmissionSummary } from "./models/submission-summary.js";
export { timeWindowSchema, type TimeWindow } from "./models/time-window.js";
export { totalsSchema, type Totals } from "./models/totals.js";
export { workerSchema, type Worker } from "./models/worker.js";
export { worker1Schema, type Worker1 } from "./models/worker1.js";

export {
  CoreError as ProofPayApiError,
  ResponseError,
  DecodeError,
  EncodeError,
  ConnectionError,
  TimeoutError,
  AuthError,
  PaginationError,
  ConfigurationError,
} from "./core/errors.js";
export { ApiError } from "./core/api-error.js";
export { SchemaError } from "./core/validation/schema-error.js";
export {
  defaultLoggingOptions,
  type LoggingOptions,
  type RequestLoggingOptions,
  type Logger,
  type LogDetails,
  type HttpRequestDetails,
  type RequestHeadersDetails,
  type RequestBodyDetails,
  type HttpResponseDetails,
  type ResponseHeadersDetails,
  type HttpRetryingDetails,
  type HttpFailedDetails,
  type LogLevel,
} from "./core/logging.js";
export type { ApiPromise, ApiResult } from "./core/api-promise.js";
export type { Pageable, PageableApiResult } from "./core/pagination/pageable.js";
export type { HttpMethod, RequestOptions } from "./core/api-request.js";
export type { RetryOptions, RequestRetryOptions, RetryAttempt, RetryReason } from "./core/retry.js";
export type { BinaryContent, BinaryData, BinaryErrorContent, FileData, FileInput } from "./core/binary.js";
export type { ErrorKind } from "./core/errors.js";
export type { Declared, Undeclared } from "./core/api-error.js";
export type { Schema, EnumSchema, Encoded, ValidationResult, JsonValue } from "./core/validation/schema.js";
