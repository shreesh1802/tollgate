import { buildAuthSchemes, type AuthSchemes } from "./auth-schemes.js";
import type { ClientOptions } from "./client-options.js";
import { buildCoreClientOptions } from "./core/client-options.js";
import { RawClient } from "./core/raw-client.js";
import * as host from "./core/runtime-environment.js";
import * as s from "./core/validation/index.js";
import { Donations } from "./resources/donations.js";
import { Evidence } from "./resources/evidence.js";
import { Projects } from "./resources/projects.js";
import { Service } from "./resources/service.js";
import { Verification } from "./resources/verification.js";
import { buildServers, type Servers } from "./servers.js";

/**
 * ProofPay holds community donations in escrow on PayPal and releases each stage payment only when
 * photo evidence passes deterministic checks plus two independent AI reviewers. Plain code makes
 * the decision; a human verifier handles held cases; every step is written to a hash-chained audit
 * log.
 *
 * **Who can call what**
 *
 * | Role | How it identifies itself | Can do |
 * |---|---|---|
 * | Anyone | nothing | read projects and the audit log, donate |
 * | Worker | `X-Worker-Key` (returned when the project is created) | upload evidence, see the current one-time code |
 * | Verifier | `X-Verifier-Key` | read the review queue, approve or reject |
 * | Organiser | `X-Organizer-Key` (only if the server sets one) | create projects |
 *
 * Money amounts are decimal strings or numbers in the project's currency (USD). The payee's email
 * address is never returned by any endpoint.
 */
export class ProofPayApiClient {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;
  readonly #auth: AuthSchemes;
  #projects?: Projects;
  #donations?: Donations;
  #evidence?: Evidence;
  #verification?: Verification;
  #service?: Service;

  constructor(options: ClientOptions = {}) {
    this.#rawClient = new RawClient({
      ...buildCoreClientOptions(options, "PROOF_PAY_API_CLIENT_LOG"),
      defaultHeaders: [
        { name: "User-Agent", value: "ProofPayApiClient/1.0.0 TypeScript", schema: s.string() },
        { name: "X-APIMatic-Lang", value: "TypeScript", schema: s.string() },
        { name: "X-APIMatic-Package-Version", value: "1.0.0", schema: s.string() },
        { name: "X-APIMatic-Gen-Version", value: "4.0.0", schema: s.string() },
        { name: "X-APIMatic-OS", value: host.operatingSystem(), schema: s.optional(s.string()) },
        { name: "X-APIMatic-Runtime", value: host.runtimeDescription(), schema: s.optional(s.string()) },
      ],
      defaultQuery: [],
      defaultPathParams: [],
    });

    this.#servers = buildServers(options);

    this.#auth = buildAuthSchemes(options);
  }

  /**
   * Create projects and read their public state and audit log.
   */
  get projects(): Projects {
    return (this.#projects ??= new Projects(this.#rawClient, this.#servers, this.#auth));
  }

  /**
   * Reserve money on PayPal. Nothing is taken until a stage is verified.
   */
  get donations(): Donations {
    return (this.#donations ??= new Donations(this.#rawClient, this.#servers));
  }

  /**
   * Upload and view the photo evidence for each stage.
   */
  get evidence(): Evidence {
    return (this.#evidence ??= new Evidence(this.#rawClient, this.#servers, this.#auth));
  }

  /**
   * The human verifier queue for held cases.
   */
  get verification(): Verification {
    return (this.#verification ??= new Verification(this.#rawClient, this.#servers, this.#auth));
  }

  /**
   * Health and configuration.
   */
  get service(): Service {
    return (this.#service ??= new Service(this.#rawClient, this.#servers));
  }
}
