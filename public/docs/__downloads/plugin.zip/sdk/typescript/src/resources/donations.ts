import { ApiError, type Declared, type Undeclared } from "../core/api-error.js";
import type { ApiPromise } from "../core/api-promise.js";
import type { RequestOptions } from "../core/api-request.js";
import { noneAuth } from "../core/auth/schemes.js";
import type { RawClient } from "../core/raw-client.js";
import type { ErrorDecoders } from "../core/response-decoder.js";
import { uuid } from "../core/uuid.js";
import * as s from "../core/validation/index.js";
import {
  apiProjectsDonationsRequestInternalSchema,
  type ApiProjectsDonationsRequest,
} from "../models/api-projects-donations-request.js";
import {
  apiProjectsDonationsResponseInternalSchema,
  type ApiProjectsDonationsResponse,
} from "../models/api-projects-donations-response.js";
import { errorSchema, type Error } from "../models/error.js";
import type { Servers } from "../servers.js";

/**
 * Reserve money on PayPal. Nothing is taken until a stage is verified.
 */
export class Donations {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;

  constructor(rawClient: RawClient, servers: Servers) {
    this.#rawClient = rawClient;
    this.#servers = servers;
  }

  /**
   * Reserve a donation on PayPal
   *
   * @remarks
   * Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and is
   * only reserved. On the sandbox, send the donor to `approveUrl` to approve it; they are then
   * returned to the site and the reservation is confirmed. In mock mode there is no approval step
   * and the donation is confirmed immediately.
   *
   * @returns Donation created.
   *
   * @throws {@link Donations.CreateDonationError} when the API answers with an error status —
   * narrow on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  createDonation(
    request: Donations.CreateDonationRequest,
    options?: RequestOptions,
  ): ApiPromise<ApiProjectsDonationsResponse, Donations.CreateDonationError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/projects/{id}/donations"),
        auth: noneAuth,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiProjectsDonationsRequestInternalSchema },
      },
      {
        success: { kind: "json", schema: apiProjectsDonationsResponseInternalSchema },
        errorFactory: Donations.CreateDonationError,
      },
      options,
    );
  }

  /**
   * PayPal return link (browser redirect)
   *
   * @remarks
   * PayPal sends the donor's browser here after approval with `?token=<order id>`. It confirms the
   * reservation and redirects back to the site. This is not meant to be called by an API client.
   *
   * @throws {@link Donations.DonationReturnError} when the API answers with an error status —
   * narrow on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  donationReturn(
    request: Donations.DonationReturnRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, Donations.DonationReturnError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/donate/return"),
        auth: noneAuth,
        pathParams: [],
        query: [
          { name: "project", value: request.project, schema: s.string() },
          { name: "donation", value: request.donation, schema: s.string() },
          { name: "token", value: request.token, schema: s.string() },
        ],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: Donations.DonationReturnError,
      },
      options,
    );
  }
}

export namespace Donations {
  export type CreateDonationRequest = {
    /** Project id. */
    id: string;
    /** Who is donating and how much. */
    body: ApiProjectsDonationsRequest;
  };

  export class CreateDonationError extends ApiError {
    declare readonly payload: Declared<"error", Error> | Declared<"error2", Error> | Undeclared;

    static readonly errors: ErrorDecoders<CreateDonationError> = [
      { on: 400, kind: "error", decode: { kind: "json", schema: errorSchema } },
      { on: 404, kind: "error2", decode: { kind: "json", schema: errorSchema } },
    ];
  }

  export type DonationReturnRequest = {
    /** Project id. */
    project: string;
    /** Donation id. */
    donation: string;
    /** The PayPal order id. */
    token: string;
  };

  export class DonationReturnError extends ApiError {
    declare readonly payload: Declared<"error302", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<DonationReturnError> = [
      { on: 302, kind: "error302", decode: { kind: "empty" } },
    ];
  }
}
