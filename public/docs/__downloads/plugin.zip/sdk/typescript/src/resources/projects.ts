import type { AuthSchemes } from "../auth-schemes.js";
import { ApiError, type Declared, type Undeclared } from "../core/api-error.js";
import type { ApiPromise } from "../core/api-promise.js";
import type { RequestOptions } from "../core/api-request.js";
import { noneAuth } from "../core/auth/schemes.js";
import type { RawClient } from "../core/raw-client.js";
import type { ErrorDecoders } from "../core/response-decoder.js";
import { uuid } from "../core/uuid.js";
import * as s from "../core/validation/index.js";
import {
  apiProjectsAuditResponseSchema,
  type ApiProjectsAuditResponse,
} from "../models/api-projects-audit-response.js";
import {
  apiProjectsResponseInternalSchema,
  type ApiProjectsResponse,
} from "../models/api-projects-response.js";
import { errorSchema, type Error } from "../models/error.js";
import { newProjectInternalSchema, type NewProject } from "../models/new-project.js";
import { projectSummarySchema, type ProjectSummary } from "../models/project-summary.js";
import { projectInternalSchema, type Project } from "../models/project.js";
import type { Servers } from "../servers.js";

/**
 * Create projects and read their public state and audit log.
 */
export class Projects {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;
  readonly #auth: AuthSchemes;

  constructor(rawClient: RawClient, servers: Servers, auth: AuthSchemes) {
    this.#rawClient = rawClient;
    this.#servers = servers;
    this.#auth = auth;
  }

  /**
   * Create a project
   *
   * @remarks
   * Stage percentages must add up to 100. Each stage has a time window in which its evidence must
   * be photographed. The response contains the worker key; keep it, it is shown once.
   *
   * @returns Project created.
   *
   * @throws {@link Projects.CreateProjectError} when the API answers with an error status — narrow
   * on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  createProject(
    request: Projects.CreateProjectRequest,
    options?: RequestOptions,
  ): ApiPromise<ApiProjectsResponse, Projects.CreateProjectError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/projects"),
        auth: this.#auth.organizerKey,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: newProjectInternalSchema },
      },
      {
        success: { kind: "json", schema: apiProjectsResponseInternalSchema },
        errorFactory: Projects.CreateProjectError,
      },
      options,
    );
  }

  /**
   * Read the audit log and check its hash chain
   *
   * @remarks
   * Every decision is an entry that includes the hash of the one before it, so altering history
   * breaks the chain.
   *
   * @returns The audit entries and the result of verifying the chain.
   *
   * @throws {@link Projects.GetAuditLogError} when the API answers with an error status — narrow on
   * `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getAuditLog(
    request: Projects.GetAuditLogRequest,
    options?: RequestOptions,
  ): ApiPromise<ApiProjectsAuditResponse, Projects.GetAuditLogError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/projects/{id}/audit"),
        auth: noneAuth,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: apiProjectsAuditResponseSchema },
        errorFactory: Projects.GetAuditLogError,
      },
      options,
    );
  }

  /**
   * Read one project
   *
   * @remarks
   * The public view: donations, totals, stages and each stage's submissions. Send `X-Worker-Key` to
   * also receive the one-time code of the active stage.
   *
   * @returns The project.
   *
   * @throws {@link Projects.GetProjectError} when the API answers with an error status — narrow on
   * `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getProject(
    request: Projects.GetProjectRequest,
    options?: RequestOptions,
  ): ApiPromise<Project, Projects.GetProjectError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/projects/{id}"),
        auth: this.#auth.workerKey,
        pathParams: [{ name: "id", value: request.id, schema: s.string() }],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: projectInternalSchema },
        errorFactory: Projects.GetProjectError,
      },
      options,
    );
  }

  /**
   * List projects
   *
   * @remarks
   * Also refreshes any payouts that PayPal has accepted but not yet settled.
   *
   * @returns Every project, in short form.
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  listProjects(options?: RequestOptions): ApiPromise<ProjectSummary[], ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/projects"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: s.array(s.lazy(() => projectSummarySchema)) },
        errorFactory: ApiError,
      },
      options,
    );
  }
}

export namespace Projects {
  export type CreateProjectRequest = {
    /** The project to create. */
    body: NewProject;
  };

  export class CreateProjectError extends ApiError {
    declare readonly payload:
      | Declared<"error", Error>
      | Declared<"error2", Error>
      | Declared<"error3", Error>
      | Undeclared;

    static readonly errors: ErrorDecoders<CreateProjectError> = [
      { on: 400, kind: "error", decode: { kind: "json", schema: errorSchema } },
      { on: 401, kind: "error2", decode: { kind: "json", schema: errorSchema } },
      { on: 429, kind: "error3", decode: { kind: "json", schema: errorSchema } },
    ];
  }

  export type GetAuditLogRequest = {
    /** Project id. */
    id: string;
  };

  export class GetAuditLogError extends ApiError {
    declare readonly payload: Declared<"error", Error> | Undeclared;

    static readonly errors: ErrorDecoders<GetAuditLogError> = [
      { on: 404, kind: "error", decode: { kind: "json", schema: errorSchema } },
    ];
  }

  export type GetProjectRequest = {
    /** Project id. */
    id: string;
  };

  export class GetProjectError extends ApiError {
    declare readonly payload: Declared<"error", Error> | Undeclared;

    static readonly errors: ErrorDecoders<GetProjectError> = [
      { on: 404, kind: "error", decode: { kind: "json", schema: errorSchema } },
    ];
  }
}
