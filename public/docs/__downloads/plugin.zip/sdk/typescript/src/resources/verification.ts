import type { AuthSchemes } from "../auth-schemes.js";
import { ApiError, type Declared, type Undeclared } from "../core/api-error.js";
import type { ApiPromise } from "../core/api-promise.js";
import type { RequestOptions } from "../core/api-request.js";
import type { RawClient } from "../core/raw-client.js";
import type { ErrorDecoders } from "../core/response-decoder.js";
import { uuid } from "../core/uuid.js";
import * as s from "../core/validation/index.js";
import { apiVerifyRequestSchema, type ApiVerifyRequest } from "../models/api-verify-request.js";
import { apiVerifyResponseSchema, type ApiVerifyResponse } from "../models/api-verify-response.js";
import { errorSchema, type Error } from "../models/error.js";
import { queueItemInternalSchema, type QueueItem } from "../models/queue-item.js";
import type { Servers } from "../servers.js";

/**
 * The human verifier queue for held cases.
 */
export class Verification {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;
  readonly #auth: AuthSchemes;

  constructor(rawClient: RawClient, servers: Servers, auth: AuthSchemes) {
    this.#rawClient = rawClient;
    this.#servers = servers;
    this.#auth = auth;
  }

  /**
   * Approve or reject a held submission
   *
   * @remarks
   * Approval is bound to the evidence the verifier saw: send the `evidenceHash` from the queue
   * item. If the evidence changed since, the call fails with 409 and nothing is released.
   *
   * @returns The submission's new status.
   *
   * @throws {@link Verification.DecideSubmissionError} when the API answers with an error status —
   * narrow on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  decideSubmission(
    request: Verification.DecideSubmissionRequest,
    options?: RequestOptions,
  ): ApiPromise<ApiVerifyResponse, Verification.DecideSubmissionError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/verify/{projectId}/{submissionId}"),
        auth: this.#auth.verifierKey,
        pathParams: [
          { name: "projectId", value: request.projectId, schema: s.string() },
          { name: "submissionId", value: request.submissionId, schema: s.string() },
        ],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiVerifyRequestSchema },
      },
      {
        success: { kind: "json", schema: apiVerifyResponseSchema },
        errorFactory: Verification.DecideSubmissionError,
      },
      options,
    );
  }

  /**
   * Submissions waiting for a human
   *
   * @remarks
   * Submissions the gate held for review, and ones whose payment release failed and needs a retry.
   *
   * @returns The queue.
   *
   * @throws {@link Verification.GetVerifierQueueError} when the API answers with an error status —
   * narrow on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getVerifierQueue(options?: RequestOptions): ApiPromise<QueueItem[], Verification.GetVerifierQueueError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/verify/queue"),
        auth: this.#auth.verifierKey,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: s.array(s.lazy(() => queueItemInternalSchema)) },
        errorFactory: Verification.GetVerifierQueueError,
      },
      options,
    );
  }
}

export namespace Verification {
  export type DecideSubmissionRequest = {
    /** Project id. */
    projectId: string;
    /** Submission id from the verifier queue. */
    submissionId: string;
    /** The verifier decision. */
    body: ApiVerifyRequest;
  };

  export class DecideSubmissionError extends ApiError {
    declare readonly payload:
      | Declared<"error", Error>
      | Declared<"error2", Error>
      | Declared<"error3", Error>
      | Declared<"error4", Error>
      | Undeclared;

    static readonly errors: ErrorDecoders<DecideSubmissionError> = [
      { on: 400, kind: "error", decode: { kind: "json", schema: errorSchema } },
      { on: 401, kind: "error2", decode: { kind: "json", schema: errorSchema } },
      { on: 409, kind: "error3", decode: { kind: "json", schema: errorSchema } },
      { on: 502, kind: "error4", decode: { kind: "json", schema: errorSchema } },
    ];
  }

  export class GetVerifierQueueError extends ApiError {
    declare readonly payload: Declared<"error", Error> | Undeclared;

    static readonly errors: ErrorDecoders<GetVerifierQueueError> = [
      { on: 401, kind: "error", decode: { kind: "json", schema: errorSchema } },
    ];
  }
}
