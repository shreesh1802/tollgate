import type { AuthSchemes } from "../auth-schemes.js";
import { ApiError, type Declared, type Undeclared } from "../core/api-error.js";
import type { ApiPromise } from "../core/api-promise.js";
import type { RequestOptions } from "../core/api-request.js";
import { anyAuth } from "../core/auth/schemes.js";
import type { RawClient } from "../core/raw-client.js";
import type { ErrorDecoders } from "../core/response-decoder.js";
import { uuid } from "../core/uuid.js";
import * as s from "../core/validation/index.js";
import { errorSchema, type Error } from "../models/error.js";
import { submissionResultInternalSchema, type SubmissionResult } from "../models/submission-result.js";
import type { Servers } from "../servers.js";

/**
 * Upload and view the photo evidence for each stage.
 */
export class Evidence {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;
  readonly #auth: AuthSchemes;

  constructor(rawClient: RawClient, servers: Servers, auth: AuthSchemes) {
    this.#rawClient = rawClient;
    this.#servers = servers;
    this.#auth = auth;
  }

  /**
   * Fetch an evidence photo
   *
   * @remarks
   * Public only after the submission has released funds. Before that, the worker or verifier key is
   * required.
   *
   * @returns The photo.
   *
   * @throws {@link Evidence.GetEvidenceImageError} when the API answers with an error status —
   * narrow on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getEvidenceImage(
    request: Evidence.GetEvidenceImageRequest,
    options?: RequestOptions,
  ): ApiPromise<undefined, Evidence.GetEvidenceImageError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/images/{projectId}/{subId}"),
        auth: anyAuth(this.#auth.workerKey, this.#auth.verifierKey),
        pathParams: [
          { name: "projectId", value: request.projectId, schema: s.string() },
          { name: "subId", value: request.subId, schema: s.string() },
        ],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "empty" },
        errorFactory: Evidence.GetEvidenceImageError,
      },
      options,
    );
  }

  /**
   * Upload photo evidence for a stage
   *
   * @remarks
   * The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates, location
   * and time from the photo's metadata, and that the one-time code is visible, then asks two
   * independent AI reviewers. The deterministic gate decides: RELEASE, RESUBMIT, HOLD (a human
   * decides) or BLOCK. On RELEASE each donor's share is captured and the worker is paid.
   *
   * On a demo server with simulated reviewers, `demoCode`, `demoMatch` and `demoFlags` steer the
   * simulated reviewers; they are ignored when real reviewers are used.
   *
   * @returns The decision for this submission.
   *
   * @throws {@link Evidence.SubmitEvidenceError} when the API answers with an error status — narrow
   * on `err.payload.kind`
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  submitEvidence(
    request: Evidence.SubmitEvidenceRequest,
    options?: RequestOptions,
  ): ApiPromise<SubmissionResult, Evidence.SubmitEvidenceError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/projects/{id}/stages/{stageId}/submissions"),
        auth: this.#auth.workerKey,
        pathParams: [
          { name: "id", value: request.id, schema: s.string() },
          { name: "stageId", value: request.stageId, schema: s.string() },
        ],
        query: [
          { name: "demoCode", value: request.demoCode, schema: s.optional(s.string()) },
          { name: "demoMatch", value: request.demoMatch, schema: s.optional(s.string()) },
          { name: "demoFlags", value: request.demoFlags, schema: s.optional(s.string()) },
        ],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: s.record(s.string(), s.unknown()) },
      },
      {
        success: { kind: "json", schema: submissionResultInternalSchema },
        errorFactory: Evidence.SubmitEvidenceError,
      },
      options,
    );
  }
}

export namespace Evidence {
  export type GetEvidenceImageRequest = {
    /** Project id. */
    projectId: string;
    /** Submission id. */
    subId: string;
  };

  export class GetEvidenceImageError extends ApiError {
    declare readonly payload: Declared<"error", Error> | Declared<"error2", Error> | Undeclared;

    static readonly errors: ErrorDecoders<GetEvidenceImageError> = [
      { on: 403, kind: "error", decode: { kind: "json", schema: errorSchema } },
      { on: 404, kind: "error2", decode: { kind: "json", schema: errorSchema } },
    ];
  }

  export type SubmitEvidenceRequest = {
    /** Project id. */
    id: string;
    /** Stage id within the project. */
    stageId: string;
    /** Simulated reviewers only. The code they report seeing. */
    demoCode?: string;
    /**
     * Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match
     * the stage; any other value means it matches.
     */
    demoMatch?: string;
    /** Simulated reviewers only. Comma-separated suspicion flags. */
    demoFlags?: string;
    /** The raw photo bytes (JPEG or PNG). */
    body: Record<string, unknown>;
  };

  export class SubmitEvidenceError extends ApiError {
    declare readonly payload:
      | Declared<"error", Error>
      | Declared<"error2", Error>
      | Declared<"error3", Error>
      | Declared<"error4", Error>
      | Declared<"error5", Error>
      | Declared<"error6", Error>
      | Declared<"error7", Error>
      | Undeclared;

    static readonly errors: ErrorDecoders<SubmitEvidenceError> = [
      { on: 400, kind: "error", decode: { kind: "json", schema: errorSchema } },
      { on: 403, kind: "error2", decode: { kind: "json", schema: errorSchema } },
      { on: 404, kind: "error3", decode: { kind: "json", schema: errorSchema } },
      { on: 409, kind: "error4", decode: { kind: "json", schema: errorSchema } },
      { on: 413, kind: "error5", decode: { kind: "json", schema: errorSchema } },
      { on: 415, kind: "error6", decode: { kind: "json", schema: errorSchema } },
      { on: 429, kind: "error7", decode: { kind: "json", schema: errorSchema } },
    ];
  }
}
