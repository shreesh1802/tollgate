import { ApiError } from "../core/api-error.js";
import type { ApiPromise } from "../core/api-promise.js";
import type { RequestOptions } from "../core/api-request.js";
import { noneAuth } from "../core/auth/schemes.js";
import type { RawClient } from "../core/raw-client.js";
import { apiConfigResponseSchema, type ApiConfigResponse } from "../models/api-config-response.js";
import { apiHealthResponseSchema, type ApiHealthResponse } from "../models/api-health-response.js";
import type { Servers } from "../servers.js";

/**
 * Health and configuration.
 */
export class Service {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;

  constructor(rawClient: RawClient, servers: Servers) {
    this.#rawClient = rawClient;
    this.#servers = servers;
  }

  /**
   * How this server is configured
   *
   * @remarks
   * Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the
   * upload size limit.
   *
   * @returns Server configuration.
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getConfig(options?: RequestOptions): ApiPromise<ApiConfigResponse, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/config"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: apiConfigResponseSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Liveness check
   *
   * @remarks
   * `uptimeSeconds` lets an operator tell a restarting process from a routing problem.
   *
   * @returns The server is up.
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link ProofPayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getHealth(options?: RequestOptions): ApiPromise<ApiHealthResponse, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/health"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: apiHealthResponseSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }
}
