import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/** The stage status object. */
export const StageStatus = {
  Pending: "PENDING",
  Active: "ACTIVE",
  Released: "RELEASED",
} as const;
export type StageStatus = (typeof StageStatus)[keyof typeof StageStatus] | (string & {});

export const stageStatusSchema: EnumSchema<StageStatus> = s.enumOf<StageStatus>(StageStatus);
