import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { decisionSchema, type Decision } from "./decision.js";
import { submissionStatusSchema, type SubmissionStatus } from "./submission-status.js";

/** The submission summary object. */
export type SubmissionSummary = {
  /** Unique identifier. */
  id?: string;
  /** The submission status object. */
  status?: SubmissionStatus;
  /** When the server received the photo (ISO 8601, UTC). */
  receivedAt?: Date;
  /** The decision object. */
  decision?: Decision;
  /** Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing. */
  reasons?: string[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const submissionSummarySchema: Schema<SubmissionSummary> = s.object<SubmissionSummary>(
  {
    id: s.optional(s.string()),
    status: s.optional(s.lazy(() => submissionStatusSchema)),
    receivedAt: s.optional(s.dateTime()),
    decision: s.optional(s.lazy(() => decisionSchema)),
    reasons: s.optional(s.array(s.string())),
  },
  { additionalProperties: s.json() },
);
