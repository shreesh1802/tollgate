import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The person who does the work and gets paid. */
export type Worker = {
  /** Full name. */
  name: string;
  /** The PayPal account that gets paid. Never published. */
  email: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const workerProperties: s.Shape<Worker> = {
  name: s.string(),
  email: s.string(),
};

export const workerInternalSchema: Schema<Worker> = s.object<Worker>(workerProperties, {
  additionalProperties: s.json(),
});

export const workerSchema: Schema<Worker> = s.lazySchema(() =>
  s.object<Worker>(
    {
      ...workerProperties,
      email: s.string().check(s.email()),
    },
    { additionalProperties: s.json() },
  ),
);
