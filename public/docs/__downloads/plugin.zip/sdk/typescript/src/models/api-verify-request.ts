import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { decision1Schema, type Decision1 } from "./decision1.js";

/** The decide submission object. */
export type ApiVerifyRequest = {
  /** The decision. */
  decision: Decision1;
  /** The hash from the queue item. Required to approve. */
  evidenceHash?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiVerifyRequestSchema: Schema<ApiVerifyRequest> = s.object<ApiVerifyRequest>(
  {
    decision: decision1Schema,
    evidenceHash: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
