import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The PayPal payout to the worker for a stage. PayPal settles it after accepting it. */
export type Payout = {
  /** Amount in the project currency. */
  amount?: string;
  /** PayPal's own payout status (for example PENDING or SUCCESS). */
  status?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const payoutSchema: Schema<Payout> = s.object<Payout>(
  {
    amount: s.optional(s.string()),
    status: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
