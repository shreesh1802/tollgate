import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** Amounts in the project currency. `paid` counts only payouts PayPal has settled. */
export type Totals = {
  /** Total reserved on PayPal from donors, not yet taken. */
  reserved?: string;
  /** Total taken from donors so far. */
  captured?: string;
  /** Total paid to the worker and settled by PayPal. */
  paid?: string;
  /** Paid out but not yet settled by PayPal. */
  inTransit?: string;
  /** Payouts that failed, were returned or are unclaimed. */
  problem?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const totalsSchema: Schema<Totals> = s.object<Totals>(
  {
    reserved: s.optional(s.string()),
    captured: s.optional(s.string()),
    paid: s.optional(s.string()),
    inTransit: s.optional(s.string()),
    problem: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
