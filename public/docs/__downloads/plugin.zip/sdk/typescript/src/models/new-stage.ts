import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { timeWindowSchema, type TimeWindow } from "./time-window.js";

/** The new stage object. */
export type NewStage = {
  /** Short human-readable title. */
  title: string;
  /** What the photo must show. The AI reviewers judge against this. */
  spec: string;
  /** Share of the total released at this stage. All stages must sum to 100. */
  pct: number;
  /** The time window object. */
  window: TimeWindow;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const newStageProperties: s.Shape<NewStage> = {
  title: s.string(),
  spec: s.string(),
  pct: s.int(),
  window: timeWindowSchema,
};

export const newStageInternalSchema: Schema<NewStage> = s.object<NewStage>(newStageProperties, {
  additionalProperties: s.json(),
});

export const newStageSchema: Schema<NewStage> = s.lazySchema(() =>
  s.object<NewStage>(
    {
      ...newStageProperties,
      pct: s.int().check(s.gte(1)),
    },
    { additionalProperties: s.json() },
  ),
);
