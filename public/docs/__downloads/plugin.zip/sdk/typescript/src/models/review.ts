import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** One independent AI reviewer's structured opinion. It advises; it never decides. */
export type Review = {
  /** Which reviewer produced this opinion. */
  reviewer?: string;
  /** Whether the photo shows what the stage requires. */
  matchesSpec?: boolean;
  /** How sure the reviewer is, from 0 to 1. */
  confidence?: number;
  /** What the reviewer saw, in plain words. */
  observations?: string;
  /** The one-time code the reviewer read in the photo, or null. */
  visibleCode?: string | null;
  /** Flags raised about the photo, such as screen-photo. */
  suspicion?: string[];
  /** Text read out of the photo. Treated as data, never as instructions. */
  textInImage?: string | null;
  /** What went wrong, in plain words. */
  error?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const reviewProperties: s.Shape<Review> = {
  reviewer: s.optional(s.string()),
  matchesSpec: s.optional(s.boolean()),
  confidence: s.optional(s.float64()),
  observations: s.optional(s.string()),
  visibleCode: s.optionalNullable(s.string()),
  suspicion: s.optional(s.array(s.string())),
  textInImage: s.optionalNullable(s.string()),
  error: s.optional(s.string()),
};

export const reviewInternalSchema: Schema<Review> = s.object<Review>(reviewProperties, {
  additionalProperties: s.json(),
});

export const reviewSchema: Schema<Review> = s.lazySchema(() =>
  s.object<Review>(
    {
      ...reviewProperties,
      confidence: s.optional(s.float64().check(s.gte(0), s.lte(1))),
    },
    { additionalProperties: s.json() },
  ),
);
