import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/** Unique identifier. */
export const Id = {
  Duplicate: "duplicate",
  Location: "location",
  Time: "time",
  Code: "code",
} as const;
export type Id = (typeof Id)[keyof typeof Id] | (string & {});

export const idSchema: EnumSchema<Id> = s.enumOf<Id>(Id);
