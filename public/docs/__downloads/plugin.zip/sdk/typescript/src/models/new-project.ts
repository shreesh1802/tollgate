import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { newStageInternalSchema, newStageSchema, type NewStage } from "./new-stage.js";
import { siteInternalSchema, siteSchema, type Site } from "./site.js";
import { workerInternalSchema, workerSchema, type Worker } from "./worker.js";

/** The new project object. */
export type NewProject = {
  /** Short human-readable title. */
  title: string;
  /** The person who does the work and gets paid. */
  worker: Worker;
  /** The site object. */
  site: Site;
  /** The stages of the project, in order. */
  stages: NewStage[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const newProjectProperties: s.Shape<NewProject> = {
  title: s.string(),
  worker: workerInternalSchema,
  site: siteInternalSchema,
  stages: s.array(s.lazy(() => newStageInternalSchema)),
};

export const newProjectInternalSchema: Schema<NewProject> = s.object<NewProject>(newProjectProperties, {
  additionalProperties: s.json(),
});

export const newProjectSchema: Schema<NewProject> = s.lazySchema(() =>
  s.object<NewProject>(
    {
      ...newProjectProperties,
      title: s.string().check(s.maxLength(100)),
      worker: workerSchema,
      site: siteSchema,
      stages: s.array(s.lazy(() => newStageSchema)).check(s.minLength(1), s.maxLength(8)),
    },
    { additionalProperties: s.json() },
  ),
);
