import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The create donation object. */
export type ApiProjectsDonationsRequest = {
  /** The donor. */
  donor: string;
  /** The amount. */
  amount: number;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const apiProjectsDonationsRequestProperties: s.Shape<ApiProjectsDonationsRequest> = {
  donor: s.string(),
  amount: s.float64(),
};

export const apiProjectsDonationsRequestInternalSchema: Schema<ApiProjectsDonationsRequest> =
  s.object<ApiProjectsDonationsRequest>(apiProjectsDonationsRequestProperties, {
    additionalProperties: s.json(),
  });

export const apiProjectsDonationsRequestSchema: Schema<ApiProjectsDonationsRequest> = s.lazySchema(() =>
  s.object<ApiProjectsDonationsRequest>(
    {
      ...apiProjectsDonationsRequestProperties,
      donor: s.string().check(s.minLength(1), s.maxLength(60)),
      amount: s.float64().check(s.gte(1), s.lte(1000), s.multipleOf(0.01)),
    },
    { additionalProperties: s.json() },
  ),
);
