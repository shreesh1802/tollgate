import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { payoutSchema, type Payout } from "./payout.js";

/** The release object. */
export type Release = {
  /** Whether the operation succeeded. */
  ok?: boolean;
  /** Why it failed, if it did. */
  reason?: string;
  /** The PayPal payout to the worker for a stage. PayPal settles it after accepting it. */
  payout?: Payout;
  /** Per-donor captures made for this release. */
  captures?: Record<string, unknown>[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const releaseSchema: Schema<Release> = s.object<Release>(
  {
    ok: s.optional(s.boolean()),
    reason: s.optional(s.string()),
    payout: s.optional(s.lazy(() => payoutSchema)),
    captures: s.optional(s.array(s.record(s.string(), s.unknown()))),
  },
  { additionalProperties: s.json() },
);
