import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The get health object. */
export type ApiHealthResponse = {
  /** The ok. */
  ok: boolean;
  /** The uptime seconds. */
  uptimeSeconds: number;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiHealthResponseSchema: Schema<ApiHealthResponse> = s.object<ApiHealthResponse>(
  {
    ok: s.boolean(),
    uptimeSeconds: s.int(),
  },
  { additionalProperties: s.json() },
);
