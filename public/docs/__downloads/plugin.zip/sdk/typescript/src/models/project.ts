import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { donationSchema, type Donation } from "./donation.js";
import { siteInternalSchema, siteSchema, type Site } from "./site.js";
import { stageSchema, type Stage } from "./stage.js";
import { totalsSchema, type Totals } from "./totals.js";
import { worker1Schema, type Worker1 } from "./worker1.js";

/** The project object. */
export type Project = {
  /** Unique identifier. */
  id?: string;
  /** Short human-readable title. */
  title?: string;
  /** When the project was created (ISO 8601, UTC). */
  startedAt?: Date | null;
  /** ISO 4217 currency code of every amount in the project. */
  currency?: string;
  /** The person who does the work and gets paid. */
  worker?: Worker1;
  /** The site object. */
  site?: Site;
  /** Every donation to the project. */
  donations?: Donation[];
  /** Amounts in the project currency. `paid` counts only payouts PayPal has settled. */
  totals?: Totals;
  /** When the earliest PayPal reservation lapses. */
  holdExpiresAt?: Date | null;
  /** The stages of the project, in order. */
  stages?: Stage[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const projectProperties: s.Shape<Project> = {
  id: s.optional(s.string()),
  title: s.optional(s.string()),
  startedAt: s.optionalNullable(s.dateTime()),
  currency: s.optional(s.string()),
  worker: s.optional(s.lazy(() => worker1Schema)),
  site: s.optional(s.lazy(() => siteInternalSchema)),
  donations: s.optional(s.array(s.lazy(() => donationSchema))),
  totals: s.optional(s.lazy(() => totalsSchema)),
  holdExpiresAt: s.optionalNullable(s.dateTime()),
  stages: s.optional(s.array(s.lazy(() => stageSchema))),
};

export const projectInternalSchema: Schema<Project> = s.object<Project>(projectProperties, {
  additionalProperties: s.json(),
});

export const projectSchema: Schema<Project> = s.lazySchema(() =>
  s.object<Project>(
    {
      ...projectProperties,
      site: s.optional(s.lazy(() => siteSchema)),
    },
    { additionalProperties: s.json() },
  ),
);
