import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { stage1Schema, type Stage1 } from "./stage1.js";
import { submissionInternalSchema, submissionSchema, type Submission } from "./submission.js";

/** The queue item object. */
export type QueueItem = {
  /** Id of the project. */
  projectId?: string;
  /** Title of the project. */
  projectTitle?: string;
  /** The stage this item belongs to. */
  stage?: Stage1;
  /** The submission waiting for review. */
  submission?: Submission;
  /** Fingerprint of the evidence the verifier is approving. Send it back unchanged. */
  evidenceHash?: string;
  /** Path of the evidence photo. */
  imageUrl?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const queueItemProperties: s.Shape<QueueItem> = {
  projectId: s.optional(s.string()),
  projectTitle: s.optional(s.string()),
  stage: s.optional(s.lazy(() => stage1Schema)),
  submission: s.optional(s.lazy(() => submissionInternalSchema)),
  evidenceHash: s.optional(s.string()),
  imageUrl: s.optional(s.string()),
};

export const queueItemInternalSchema: Schema<QueueItem> = s.object<QueueItem>(queueItemProperties, {
  additionalProperties: s.json(),
});

export const queueItemSchema: Schema<QueueItem> = s.lazySchema(() =>
  s.object<QueueItem>(
    {
      ...queueItemProperties,
      submission: s.optional(s.lazy(() => submissionSchema)),
    },
    { additionalProperties: s.json() },
  ),
);
