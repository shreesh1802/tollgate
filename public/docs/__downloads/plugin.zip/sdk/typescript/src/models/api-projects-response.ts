import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The create project object. */
export type ApiProjectsResponse = {
  /** The id. */
  id: string;
  /** The worker key. */
  workerKey: string;
  /** A link that opens the worker page already signed in. */
  workerLink: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const apiProjectsResponseProperties: s.Shape<ApiProjectsResponse> = {
  id: s.string(),
  workerKey: s.string(),
  workerLink: s.string(),
};

export const apiProjectsResponseInternalSchema: Schema<ApiProjectsResponse> = s.object<ApiProjectsResponse>(
  apiProjectsResponseProperties,
  { additionalProperties: s.json() },
);

export const apiProjectsResponseSchema: Schema<ApiProjectsResponse> = s.lazySchema(() =>
  s.object<ApiProjectsResponse>(
    {
      ...apiProjectsResponseProperties,
      workerLink: s.string().check(s.url()),
    },
    { additionalProperties: s.json() },
  ),
);
