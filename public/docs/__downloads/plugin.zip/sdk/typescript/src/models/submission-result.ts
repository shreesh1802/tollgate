import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { checkSchema, type Check } from "./check.js";
import { decisionSchema, type Decision } from "./decision.js";
import { releaseSchema, type Release } from "./release.js";
import { reviewInternalSchema, reviewSchema, type Review } from "./review.js";
import { submissionStatusSchema, type SubmissionStatus } from "./submission-status.js";

/** The submission result object. */
export type SubmissionResult = {
  /** The decision object. */
  decision?: Decision;
  /** The submission status object. */
  status?: SubmissionStatus;
  /** Id of the submission. */
  submissionId?: string;
  /** Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing. */
  reasons?: Record<string, unknown>[];
  /** Results of the deterministic checks. */
  checks?: Check[];
  /** Opinions of the two independent AI reviewers. */
  reviews?: Review[];
  /** The release object. */
  release?: Release;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const submissionResultProperties: s.Shape<SubmissionResult> = {
  decision: s.optional(s.lazy(() => decisionSchema)),
  status: s.optional(s.lazy(() => submissionStatusSchema)),
  submissionId: s.optional(s.string()),
  reasons: s.optional(s.array(s.record(s.string(), s.unknown()))),
  checks: s.optional(s.array(s.lazy(() => checkSchema))),
  reviews: s.optional(s.array(s.lazy(() => reviewInternalSchema))),
  release: s.optional(s.lazy(() => releaseSchema)),
};

export const submissionResultInternalSchema: Schema<SubmissionResult> = s.object<SubmissionResult>(
  submissionResultProperties,
  { additionalProperties: s.json() },
);

export const submissionResultSchema: Schema<SubmissionResult> = s.lazySchema(() =>
  s.object<SubmissionResult>(
    {
      ...submissionResultProperties,
      reviews: s.optional(s.array(s.lazy(() => reviewSchema))),
    },
    { additionalProperties: s.json() },
  ),
);
