import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { releaseSchema, type Release } from "./release.js";
import { submissionStatusSchema, type SubmissionStatus } from "./submission-status.js";

/** The decide submission object. */
export type ApiVerifyResponse = {
  /** The submission status object. */
  status: SubmissionStatus;
  /** The release object. */
  release?: Release;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiVerifyResponseSchema: Schema<ApiVerifyResponse> = s.object<ApiVerifyResponse>(
  {
    status: submissionStatusSchema,
    release: s.optional(s.lazy(() => releaseSchema)),
  },
  { additionalProperties: s.json() },
);
