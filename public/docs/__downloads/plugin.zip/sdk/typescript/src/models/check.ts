import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { idSchema, type Id } from "./id.js";
import { statusSchema, type Status } from "./status.js";

/** The check object. */
export type Check = {
  /** Unique identifier. */
  id?: Id;
  /** Current state. */
  status?: Status;
  /** Explanation of the result. */
  detail?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const checkSchema: Schema<Check> = s.object<Check>(
  {
    id: s.optional(s.lazy(() => idSchema)),
    status: s.optional(s.lazy(() => statusSchema)),
    detail: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
