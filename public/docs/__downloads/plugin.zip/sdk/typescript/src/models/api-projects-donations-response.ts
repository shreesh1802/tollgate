import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { donationStatusSchema, type DonationStatus } from "./donation-status.js";

/** The create donation object. */
export type ApiProjectsDonationsResponse = {
  /** The donation id. */
  donationId: string;
  /**
   * AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED
   * = not approved.
   */
  status: DonationStatus;
  /** Where the donor approves the reservation. Absent in mock mode. */
  approveUrl?: string | null;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const apiProjectsDonationsResponseProperties: s.Shape<ApiProjectsDonationsResponse> = {
  donationId: s.string(),
  status: donationStatusSchema,
  approveUrl: s.optionalNullable(s.string()),
};

export const apiProjectsDonationsResponseInternalSchema: Schema<ApiProjectsDonationsResponse> =
  s.object<ApiProjectsDonationsResponse>(apiProjectsDonationsResponseProperties, {
    additionalProperties: s.json(),
  });

export const apiProjectsDonationsResponseSchema: Schema<ApiProjectsDonationsResponse> = s.lazySchema(() =>
  s.object<ApiProjectsDonationsResponse>(
    {
      ...apiProjectsDonationsResponseProperties,
      approveUrl: s.optionalNullable(s.string().check(s.url())),
    },
    { additionalProperties: s.json() },
  ),
);
