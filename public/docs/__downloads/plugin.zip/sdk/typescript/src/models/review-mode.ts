import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/** The review mode. */
export const ReviewMode = {
  Demo: "demo",
  Claude: "claude",
} as const;
export type ReviewMode = (typeof ReviewMode)[keyof typeof ReviewMode] | (string & {});

export const reviewModeSchema: EnumSchema<ReviewMode> = s.enumOf<ReviewMode>(ReviewMode);
