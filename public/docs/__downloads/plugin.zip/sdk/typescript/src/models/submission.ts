import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { checkSchema, type Check } from "./check.js";
import { reviewInternalSchema, reviewSchema, type Review } from "./review.js";
import { submissionStatusSchema, type SubmissionStatus } from "./submission-status.js";

/** The submission waiting for review. */
export type Submission = {
  /** Unique identifier. */
  id?: string;
  /** The submission status object. */
  status?: SubmissionStatus;
  /** Why the payment release failed, if it did. */
  releaseError?: string | null;
  /** When the server received the photo (ISO 8601, UTC). */
  receivedAt?: Date;
  /** Facts read from the photo: time, location, perceptual hash. */
  facts?: Record<string, unknown>;
  /** Opinions of the two independent AI reviewers. */
  reviews?: Review[];
  /** Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing. */
  reasons?: Record<string, unknown>[];
  /** Results of the deterministic checks. */
  checks?: Check[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const submissionProperties: s.Shape<Submission> = {
  id: s.optional(s.string()),
  status: s.optional(s.lazy(() => submissionStatusSchema)),
  releaseError: s.optionalNullable(s.string()),
  receivedAt: s.optional(s.dateTime()),
  facts: s.optional(s.record(s.string(), s.unknown())),
  reviews: s.optional(s.array(s.lazy(() => reviewInternalSchema))),
  reasons: s.optional(s.array(s.record(s.string(), s.unknown()))),
  checks: s.optional(s.array(s.lazy(() => checkSchema))),
};

export const submissionInternalSchema: Schema<Submission> = s.object<Submission>(submissionProperties, {
  additionalProperties: s.json(),
});

export const submissionSchema: Schema<Submission> = s.lazySchema(() =>
  s.object<Submission>(
    {
      ...submissionProperties,
      reviews: s.optional(s.array(s.lazy(() => reviewSchema))),
    },
    { additionalProperties: s.json() },
  ),
);
