import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/** The submission status object. */
export const SubmissionStatus = {
  Received: "RECEIVED",
  Released: "RELEASED",
  PendingReview: "PENDING_REVIEW",
  Resubmit: "RESUBMIT",
  Blocked: "BLOCKED",
  Rejected: "REJECTED",
  ReleaseFailed: "RELEASE_FAILED",
} as const;
export type SubmissionStatus = (typeof SubmissionStatus)[keyof typeof SubmissionStatus] | (string & {});

export const submissionStatusSchema: EnumSchema<SubmissionStatus> =
  s.enumOf<SubmissionStatus>(SubmissionStatus);
