import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { stageStatusSchema, type StageStatus } from "./stage-status.js";
import { totalsSchema, type Totals } from "./totals.js";

/** The project summary object. */
export type ProjectSummary = {
  /** Unique identifier. */
  id?: string;
  /** Short human-readable title. */
  title?: string;
  /** Amounts in the project currency. `paid` counts only payouts PayPal has settled. */
  totals?: Totals;
  /** The stages of the project, in order. */
  stages?: StageStatus[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const projectSummarySchema: Schema<ProjectSummary> = s.object<ProjectSummary>(
  {
    id: s.optional(s.string()),
    title: s.optional(s.string()),
    totals: s.optional(s.lazy(() => totalsSchema)),
    stages: s.optional(s.array(s.lazy(() => stageStatusSchema))),
  },
  { additionalProperties: s.json() },
);
