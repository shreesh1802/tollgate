import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { releaseSchema, type Release } from "./release.js";
import { stageStatusSchema, type StageStatus } from "./stage-status.js";
import { submissionSummarySchema, type SubmissionSummary } from "./submission-summary.js";
import { timeWindowSchema, type TimeWindow } from "./time-window.js";

/** The stage object. */
export type Stage = {
  /** Unique identifier. */
  id?: string;
  /** Position of the stage, starting at 0. */
  index?: number;
  /** Short human-readable title. */
  title?: string;
  /** What the photo must show for this stage. The AI reviewers judge against this text. */
  spec?: string;
  /** Share of the total released at this stage, as a whole percent. All stages sum to 100. */
  pct?: number;
  /** The time window object. */
  window?: TimeWindow;
  /** The stage status object. */
  status?: StageStatus;
  /** The release object. */
  release?: Release;
  /** When the stage payment was released (ISO 8601, UTC). */
  releasedAt?: Date | null;
  /**
   * The one-time code to write on paper in the photo. Only returned to the worker, only while the
   * stage is ACTIVE.
   */
  code?: string;
  /** Evidence uploads for this stage. */
  submissions?: SubmissionSummary[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const stageSchema: Schema<Stage> = s.object<Stage>(
  {
    id: s.optional(s.string()),
    index: s.optional(s.int()),
    title: s.optional(s.string()),
    spec: s.optional(s.string()),
    pct: s.optional(s.int()),
    window: s.optional(s.lazy(() => timeWindowSchema)),
    status: s.optional(s.lazy(() => stageStatusSchema)),
    release: s.optional(s.lazy(() => releaseSchema)),
    releasedAt: s.optionalNullable(s.dateTime()),
    code: s.optional(s.string()),
    submissions: s.optional(s.array(s.lazy(() => submissionSummarySchema))),
  },
  { additionalProperties: s.json() },
);
