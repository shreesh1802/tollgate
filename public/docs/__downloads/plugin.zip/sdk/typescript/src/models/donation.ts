import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { donationStatusSchema, type DonationStatus } from "./donation-status.js";

/** The donation object. */
export type Donation = {
  /** Unique identifier. */
  id?: string;
  /** Display name of the donor. */
  donor?: string;
  /** Amount in the project currency. */
  amount?: number;
  /**
   * AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED
   * = not approved.
   */
  status?: DonationStatus;
  /** How much of this donation has been captured so far. */
  released?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const donationSchema: Schema<Donation> = s.object<Donation>(
  {
    id: s.optional(s.string()),
    donor: s.optional(s.string()),
    amount: s.optional(s.float64()),
    status: s.optional(s.lazy(() => donationStatusSchema)),
    released: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
