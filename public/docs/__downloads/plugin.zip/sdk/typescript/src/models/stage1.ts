import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The stage this item belongs to. */
export type Stage1 = {
  /** Unique identifier. */
  id?: string;
  /** Short human-readable title. */
  title?: string;
  /** What the photo must show for this stage. The AI reviewers judge against this text. */
  spec?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const stage1Schema: Schema<Stage1> = s.object<Stage1>(
  {
    id: s.optional(s.string()),
    title: s.optional(s.string()),
    spec: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
