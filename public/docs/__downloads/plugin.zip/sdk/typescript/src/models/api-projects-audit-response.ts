import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { chainSchema, type Chain } from "./chain.js";

/** The get audit log object. */
export type ApiProjectsAuditResponse = {
  /** Result of re-computing the hash chain. */
  chain: Chain;
  /** The entries. */
  entries: Record<string, unknown>[];
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiProjectsAuditResponseSchema: Schema<ApiProjectsAuditResponse> =
  s.object<ApiProjectsAuditResponse>(
    {
      chain: chainSchema,
      entries: s.array(s.record(s.string(), s.unknown())),
    },
    { additionalProperties: s.json() },
  );
