import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The time window object. */
export type TimeWindow = {
  /** Start of the window (ISO 8601). */
  from: Date;
  /** End of the window (ISO 8601). */
  to: Date;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const timeWindowSchema: Schema<TimeWindow> = s.object<TimeWindow>(
  {
    from: s.dateTime(),
    to: s.dateTime(),
  },
  { additionalProperties: s.json() },
);
