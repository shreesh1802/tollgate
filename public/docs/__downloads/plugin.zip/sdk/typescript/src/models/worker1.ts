import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The person who does the work and gets paid. */
export type Worker1 = {
  /** Full name. */
  name?: string;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const worker1Schema: Schema<Worker1> = s.object<Worker1>(
  {
    name: s.optional(s.string()),
  },
  { additionalProperties: s.json() },
);
