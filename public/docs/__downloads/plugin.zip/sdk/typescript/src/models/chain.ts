import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** Result of re-computing the hash chain. */
export type Chain = {
  /** The ok. */
  ok?: boolean;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const chainSchema: Schema<Chain> = s.object<Chain>(
  {
    ok: s.optional(s.boolean()),
  },
  { additionalProperties: s.json() },
);
