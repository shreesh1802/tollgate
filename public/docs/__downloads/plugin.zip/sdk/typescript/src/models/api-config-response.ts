import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";
import { modeSchema, type Mode } from "./mode.js";
import { reviewModeSchema, type ReviewMode } from "./review-mode.js";

/** The get config object. */
export type ApiConfigResponse = {
  /** The mode. */
  mode: Mode;
  /** The review mode. */
  reviewMode: ReviewMode;
  /** The simulated reviews. */
  simulatedReviews: boolean;
  /** The max upload bytes. */
  maxUploadBytes: number;
  /** The vendors. */
  vendors?: string[];
  /**
   * Present only on the hosted demo. Contains the demo project and role keys so a visitor can try
   * every role.
   */
  demo?: Record<string, unknown> | null;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

export const apiConfigResponseSchema: Schema<ApiConfigResponse> = s.object<ApiConfigResponse>(
  {
    mode: modeSchema,
    reviewMode: reviewModeSchema,
    simulatedReviews: s.boolean(),
    maxUploadBytes: s.int(),
    vendors: s.optional(s.array(s.string())),
    demo: s.optionalNullable(s.record(s.string(), s.unknown())),
  },
  { additionalProperties: s.json() },
);
