import * as s from "../core/validation/index.js";
import type { JsonValue, Schema } from "../core/validation/schema.js";

/** The site object. */
export type Site = {
  /** Latitude of the job site in degrees. */
  lat: number;
  /** Longitude of the job site in degrees. */
  lon: number;
  /** Photos must be taken within this many metres. */
  radiusM: number;
  /** Properties the service sent or accepts beyond those declared. */
  additionalProperties?: Record<string, JsonValue>;
};

const siteProperties: s.Shape<Site> = {
  lat: s.float64(),
  lon: s.float64(),
  radiusM: s.float64(),
};

export const siteInternalSchema: Schema<Site> = s.object<Site>(siteProperties, {
  additionalProperties: s.json(),
});

export const siteSchema: Schema<Site> = s.lazySchema(() =>
  s.object<Site>(
    {
      ...siteProperties,
      lat: s.float64().check(s.gte(-90), s.lte(90)),
      lon: s.float64().check(s.gte(-180), s.lte(180)),
      radiusM: s.float64().check(s.gte(10), s.lte(5000)),
    },
    { additionalProperties: s.json() },
  ),
);
