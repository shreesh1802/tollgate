import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/**
 * AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED =
 * not approved.
 */
export const DonationStatus = {
  AwaitingApproval: "AWAITING_APPROVAL",
  Confirmed: "CONFIRMED",
  Failed: "FAILED",
} as const;
export type DonationStatus = (typeof DonationStatus)[keyof typeof DonationStatus] | (string & {});

export const donationStatusSchema: EnumSchema<DonationStatus> = s.enumOf<DonationStatus>(DonationStatus);
