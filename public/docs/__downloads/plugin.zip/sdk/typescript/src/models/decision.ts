import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

/** The decision object. */
export const Decision = {
  Release: "RELEASE",
  Resubmit: "RESUBMIT",
  Hold: "HOLD",
  Block: "BLOCK",
} as const;
export type Decision = (typeof Decision)[keyof typeof Decision] | (string & {});

export const decisionSchema: EnumSchema<Decision> = s.enumOf<Decision>(Decision);
