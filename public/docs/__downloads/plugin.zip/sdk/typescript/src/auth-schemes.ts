import type { ClientOptions } from "./client-options.js";
import type { AuthScheme } from "./core/api-request.js";
import { apiKeyHeaderAuth } from "./core/auth/schemes.js";

export type AuthSchemes = {
  readonly workerKey: AuthScheme;
  readonly verifierKey: AuthScheme;
  readonly organizerKey: AuthScheme;
};

export function buildAuthSchemes(options: ClientOptions): AuthSchemes {
  return {
    workerKey: apiKeyHeaderAuth({ name: "X-Worker-Key", token: options.workerKey }),
    verifierKey: apiKeyHeaderAuth({ name: "X-Verifier-Key", token: options.verifierKey }),
    organizerKey: apiKeyHeaderAuth({ name: "X-Organizer-Key", token: options.organizerKey }),
  };
}
