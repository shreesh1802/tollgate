# Reference

> Source: [ProofPayApiClient](src/client.ts)

## Projects

> Source: [Projects](src/resources/projects.ts)

<details>
<summary><code>createProject(request: Projects.CreateProjectRequest, options?: RequestOptions): ApiPromise&lt;ApiProjectsResponse, Projects.CreateProjectError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Stage percentages must add up to 100. Each stage has a time window in which its evidence
must be photographed. The response contains the worker key; keep it, it is shown once.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.projects.createProject({
    body: {
      title: "Repair the village hand pump",
      worker: { name: "Ravi Kumar", email: "ravi@example.com" },
      site: { lat: 12.9716, lon: 77.5946, radiusM: 150 },
      stages: [
        {
          title: "Repair the village hand pump",
          spec: "The new pump head is installed and bolted to the base.",
          pct: 40,
          window: {
            from: new Date(Date.UTC(2026, 10, 1, 0, 0, 0)),
            to: new Date(Date.UTC(2026, 10, 30, 23, 59, 59)),
          },
        },
      ],
    },
  });
  // TODO: Handle 'response' of type ApiProjectsResponse
} catch (err) {
  // TODO: Handle 'err' of type Projects.CreateProjectError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.projects
  .createProject({
    body: {
      title: "Repair the village hand pump",
      worker: { name: "Ravi Kumar", email: "ravi@example.com" },
      site: { lat: 12.9716, lon: 77.5946, radiusM: 150 },
      stages: [
        {
          title: "Repair the village hand pump",
          spec: "The new pump head is installed and bolted to the base.",
          pct: 40,
          window: {
            from: new Date(Date.UTC(2026, 10, 1, 0, 0, 0)),
            to: new Date(Date.UTC(2026, 10, 30, 23, 59, 59)),
          },
        },
      ],
    },
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiProjectsResponse
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[NewProject](src/models/new-project.ts)</code> | The project to create. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.projects.createProject(request)`

- **OnSuccess**: <code>[ApiProjectsResponse](src/models/api-projects-response.ts)</code>
- **OnError**: throws <code>[Projects.CreateProjectError](src/resources/projects.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.projects.createProject(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiProjectsResponse, Projects.CreateProjectError&gt;</code>, with `result.value` of type <code>[ApiProjectsResponse](src/models/api-projects-response.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getAuditLog(request: Projects.GetAuditLogRequest, options?: RequestOptions): ApiPromise&lt;ApiProjectsAuditResponse, Projects.GetAuditLogError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.projects.getAuditLog({ id: "P1" });
  // TODO: Handle 'response' of type ApiProjectsAuditResponse
} catch (err) {
  // TODO: Handle 'err' of type Projects.GetAuditLogError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.projects.getAuditLog({ id: "P1" }).asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiProjectsAuditResponse
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | Project id. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.projects.getAuditLog(request)`

- **OnSuccess**: <code>[ApiProjectsAuditResponse](src/models/api-projects-audit-response.ts)</code>
- **OnError**: throws <code>[Projects.GetAuditLogError](src/resources/projects.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.projects.getAuditLog(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiProjectsAuditResponse, Projects.GetAuditLogError&gt;</code>, with `result.value` of type <code>[ApiProjectsAuditResponse](src/models/api-projects-audit-response.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getProject(request: Projects.GetProjectRequest, options?: RequestOptions): ApiPromise&lt;Project, Projects.GetProjectError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The public view: donations, totals, stages and each stage's submissions. Send
`X-Worker-Key` to also receive the one-time code of the active stage.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.projects.getProject({ id: "P1" });
  // TODO: Handle 'response' of type Project
} catch (err) {
  // TODO: Handle 'err' of type Projects.GetProjectError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.projects.getProject({ id: "P1" }).asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type Project
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | Project id. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.projects.getProject(request)`

- **OnSuccess**: <code>[Project](src/models/project.ts)</code>
- **OnError**: throws <code>[Projects.GetProjectError](src/resources/projects.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.projects.getProject(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;Project, Projects.GetProjectError&gt;</code>, with `result.value` of type <code>[Project](src/models/project.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>listProjects(options?: RequestOptions): ApiPromise&lt;ProjectSummary[], ApiError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Also refreshes any payouts that PayPal has accepted but not yet settled.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.projects.listProjects();
  // TODO: Handle 'response' of type ProjectSummary[]
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.projects.listProjects().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ProjectSummary[]
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.projects.listProjects()`

- **OnSuccess**: <code>[ProjectSummary](src/models/project-summary.ts)[]</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.projects.listProjects().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ProjectSummary[], ApiError&gt;</code>, with `result.value` of type <code>[ProjectSummary](src/models/project-summary.ts)[]</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

## Donations

> Source: [Donations](src/resources/donations.ts)

<details>
<summary><code>createDonation(request: Donations.CreateDonationRequest, options?: RequestOptions): ApiPromise&lt;ApiProjectsDonationsResponse, Donations.CreateDonationError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and
is only reserved. On the sandbox, send the donor to `approveUrl` to approve it; they are
then returned to the site and the reservation is confirmed. In mock mode there is no
approval step and the donation is confirmed immediately.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.donations.createDonation({ id: "P1", body: { donor: "Asha", amount: 25 } });
  // TODO: Handle 'response' of type ApiProjectsDonationsResponse
} catch (err) {
  // TODO: Handle 'err' of type Donations.CreateDonationError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.donations
  .createDonation({ id: "P1", body: { donor: "Asha", amount: 25 } })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiProjectsDonationsResponse
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | Project id. |
| <code>body</code> | <code>[ApiProjectsDonationsRequest](src/models/api-projects-donations-request.ts)</code> | Who is donating and how much. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.donations.createDonation(request)`

- **OnSuccess**: <code>[ApiProjectsDonationsResponse](src/models/api-projects-donations-response.ts)</code>
- **OnError**: throws <code>[Donations.CreateDonationError](src/resources/donations.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.donations.createDonation(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiProjectsDonationsResponse, Donations.CreateDonationError&gt;</code>, with `result.value` of type <code>[ApiProjectsDonationsResponse](src/models/api-projects-donations-response.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>donationReturn(request: Donations.DonationReturnRequest, options?: RequestOptions): ApiPromise&lt;undefined, Donations.DonationReturnError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal sends the donor's browser here after approval with `?token=<order id>`. It confirms
the reservation and redirects back to the site. This is not meant to be called by an API client.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.donations.donationReturn({ project: "P1", donation: "D1", token: "5O190127" });
} catch (err) {
  // TODO: Handle 'err' of type Donations.DonationReturnError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.donations
  .donationReturn({ project: "P1", donation: "D1", token: "5O190127" })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>project</code> | <code>string</code> | Project id. |
| <code>donation</code> | <code>string</code> | Donation id. |
| <code>token</code> | <code>string</code> | The PayPal order id. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.donations.donationReturn(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[Donations.DonationReturnError](src/resources/donations.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.donations.donationReturn(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, Donations.DonationReturnError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

## Evidence

> Source: [Evidence](src/resources/evidence.ts)

<details>
<summary><code>getEvidenceImage(request: Evidence.GetEvidenceImageRequest, options?: RequestOptions): ApiPromise&lt;undefined, Evidence.GetEvidenceImageError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Public only after the submission has released funds. Before that, the worker or verifier key is required.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  await client.evidence.getEvidenceImage({ projectId: "P1", subId: "S1-1" });
} catch (err) {
  // TODO: Handle 'err' of type Evidence.GetEvidenceImageError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.evidence.getEvidenceImage({ projectId: "P1", subId: "S1-1" }).asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: The call succeeded and resolves to no body
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>projectId</code> | <code>string</code> | Project id. |
| <code>subId</code> | <code>string</code> | Submission id. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.evidence.getEvidenceImage(request)`

- **OnSuccess**: <code>undefined</code>
- **OnError**: throws <code>[Evidence.GetEvidenceImageError](src/resources/evidence.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.evidence.getEvidenceImage(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;undefined, Evidence.GetEvidenceImageError&gt;</code>, with `result.value` of type <code>undefined</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>submitEvidence(request: Evidence.SubmitEvidenceRequest, options?: RequestOptions): ApiPromise&lt;SubmissionResult, Evidence.SubmitEvidenceError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates,
location and time from the photo's metadata, and that the one-time code is visible, then
asks two independent AI reviewers. The deterministic gate decides: RELEASE, RESUBMIT,
HOLD (a human decides) or BLOCK. On RELEASE each donor's share is captured and the worker
is paid.

On a demo server with simulated reviewers, `demoCode`, `demoMatch` and `demoFlags` steer
the simulated reviewers; they are ignored when real reviewers are used.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.evidence.submitEvidence({
    id: "P1",
    stageId: "S1",
    demoCode: "demoCode",
    demoMatch: "0",
    demoFlags: "demoFlags",
    body: {},
  });
  // TODO: Handle 'response' of type SubmissionResult
} catch (err) {
  // TODO: Handle 'err' of type Evidence.SubmitEvidenceError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.evidence
  .submitEvidence({
    id: "P1",
    stageId: "S1",
    demoCode: "demoCode",
    demoMatch: "0",
    demoFlags: "demoFlags",
    body: {},
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type SubmissionResult
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id</code> | <code>string</code> | Project id. |
| <code>stageId</code> | <code>string</code> | Stage id within the project. |
| <code>demoCode?</code> | <code>string</code> | Simulated reviewers only. The code they report seeing. |
| <code>demoMatch?</code> | <code>string</code> | Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match the stage; any other value means it matches. |
| <code>demoFlags?</code> | <code>string</code> | Simulated reviewers only. Comma-separated suspicion flags. |
| <code>body</code> | <code>Record&lt;string, unknown&gt;</code> | The raw photo bytes (JPEG or PNG). |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.evidence.submitEvidence(request)`

- **OnSuccess**: <code>[SubmissionResult](src/models/submission-result.ts)</code>
- **OnError**: throws <code>[Evidence.SubmitEvidenceError](src/resources/evidence.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.evidence.submitEvidence(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;SubmissionResult, Evidence.SubmitEvidenceError&gt;</code>, with `result.value` of type <code>[SubmissionResult](src/models/submission-result.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

## Verification

> Source: [Verification](src/resources/verification.ts)

<details>
<summary><code>decideSubmission(request: Verification.DecideSubmissionRequest, options?: RequestOptions): ApiPromise&lt;ApiVerifyResponse, Verification.DecideSubmissionError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Approval is bound to the evidence the verifier saw: send the `evidenceHash` from the queue
item. If the evidence changed since, the call fails with 409 and nothing is released.


</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.verification.decideSubmission({
    projectId: "P1",
    submissionId: "S1-1",
    body: { decision: Decision1.Approve, evidenceHash: "evidenceHash" },
  });
  // TODO: Handle 'response' of type ApiVerifyResponse
} catch (err) {
  // TODO: Handle 'err' of type Verification.DecideSubmissionError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.verification
  .decideSubmission({
    projectId: "P1",
    submissionId: "S1-1",
    body: { decision: Decision1.Approve, evidenceHash: "evidenceHash" },
  })
  .asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiVerifyResponse
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>projectId</code> | <code>string</code> | Project id. |
| <code>submissionId</code> | <code>string</code> | Submission id from the verifier queue. |
| <code>body</code> | <code>[ApiVerifyRequest](src/models/api-verify-request.ts)</code> | The verifier decision. |

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.verification.decideSubmission(request)`

- **OnSuccess**: <code>[ApiVerifyResponse](src/models/api-verify-response.ts)</code>
- **OnError**: throws <code>[Verification.DecideSubmissionError](src/resources/verification.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.verification.decideSubmission(request).asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiVerifyResponse, Verification.DecideSubmissionError&gt;</code>, with `result.value` of type <code>[ApiVerifyResponse](src/models/api-verify-response.ts)</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getVerifierQueue(options?: RequestOptions): ApiPromise&lt;QueueItem[], Verification.GetVerifierQueueError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Submissions the gate held for review, and ones whose payment release failed and needs a retry.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.verification.getVerifierQueue();
  // TODO: Handle 'response' of type QueueItem[]
} catch (err) {
  // TODO: Handle 'err' of type Verification.GetVerifierQueueError, discriminated with 'err.payload.kind'
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.verification.getVerifierQueue().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type QueueItem[]
} else {
  // TODO: Handle 'result', discriminated with 'result.payload.kind'
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.verification.getVerifierQueue()`

- **OnSuccess**: <code>[QueueItem](src/models/queue-item.ts)[]</code>
- **OnError**: throws <code>[Verification.GetVerifierQueueError](src/resources/verification.ts)</code>, with `err.payload` discriminated on `kind`

**As ApiResult**: `await client.verification.getVerifierQueue().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;QueueItem[], Verification.GetVerifierQueueError&gt;</code>, with `result.value` of type <code>[QueueItem](src/models/queue-item.ts)[]</code>
- **OnError**: `result.payload` discriminated on `kind`, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

## Service

> Source: [Service](src/resources/service.ts)

<details>
<summary><code>getConfig(options?: RequestOptions): ApiPromise&lt;ApiConfigResponse, ApiError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size limit.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.service.getConfig();
  // TODO: Handle 'response' of type ApiConfigResponse
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.service.getConfig().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiConfigResponse
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.service.getConfig()`

- **OnSuccess**: <code>[ApiConfigResponse](src/models/api-config-response.ts)</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.service.getConfig().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiConfigResponse, ApiError&gt;</code>, with `result.value` of type <code>[ApiConfigResponse](src/models/api-config-response.ts)</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>getHealth(options?: RequestOptions): ApiPromise&lt;ApiHealthResponse, ApiError&gt;</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

`uptimeSeconds` lets an operator tell a restarting process from a routing problem.

</dd>
</dl>

### Direct Usage

<dl>
<dd>

```ts
try {
  const response = await client.service.getHealth();
  // TODO: Handle 'response' of type ApiHealthResponse
} catch (err) {
  // TODO: Handle 'err' of type ApiError, where 'err.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Usage as ApiResult

<dl>
<dd>

```ts
const result = await client.service.getHealth().asApiResult();
// TODO: Use 'result.status' and 'result.headers' to read the raw response status and headers
if (result.ok) {
  // TODO: Use 'result.value' of type ApiHealthResponse
} else {
  // TODO: Handle 'result', where 'result.payload' is always the Undeclared arm
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**Direct**: `await client.service.getHealth()`

- **OnSuccess**: <code>[ApiHealthResponse](src/models/api-health-response.ts)</code>
- **OnError**: throws <code>[ApiError](src/core/api-error.ts)</code>, with `err.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm

**As ApiResult**: `await client.service.getHealth().asApiResult()`

- **OnSuccess**: <code>[ApiResult](src/core/api-promise.ts)&lt;ApiHealthResponse, ApiError&gt;</code>, with `result.value` of type <code>[ApiHealthResponse](src/models/api-health-response.ts)</code>
- **OnError**: `result.payload` always the <code>[Undeclared](src/core/api-error.ts)</code> arm, with `result.message`

**Thrown**: <code>[ProofPayApiError](src/core/errors.ts)</code> on any operational failure — a caller abort and a programmer error stay outside the family and reach you raw

</dd>
</dl>

</dd>
</dl>

</details>

