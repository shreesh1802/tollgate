<!-- Generated file — do not edit; regenerated with the SDK. -->

# Projects — operations

Accessor: `client.projects` · Source: `src/resources/projects.ts` · 4 operations · Request and error types: namespace `Projects`

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `proof-pay-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### createProject

- **Signature**: `createProject(request: Projects.CreateProjectRequest, options?: RequestOptions): ApiPromise<ApiProjectsResponse, Projects.CreateProjectError>`
- **Wire**: `POST /api/projects`
- **Auth**: `organizerKey`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `ApiProjectsResponse`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Projects.CreateProjectError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [400] `Error` · `"error2"` [401] `Error` · `"error3"` [429] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Projects.CreateProjectRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `NewProject` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `NewProject` | `newProjectSchema` | `src/models/new-project.ts` |
| `ApiProjectsResponse` | `apiProjectsResponseSchema` | `src/models/api-projects-response.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

### getAuditLog

- **Signature**: `getAuditLog(request: Projects.GetAuditLogRequest, options?: RequestOptions): ApiPromise<ApiProjectsAuditResponse, Projects.GetAuditLogError>`
- **Wire**: `GET /api/projects/{id}/audit`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `ApiProjectsAuditResponse`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Projects.GetAuditLogError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [404] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Projects.GetAuditLogRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiProjectsAuditResponse` | `apiProjectsAuditResponseSchema` | `src/models/api-projects-audit-response.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

### getProject

- **Signature**: `getProject(request: Projects.GetProjectRequest, options?: RequestOptions): ApiPromise<Project, Projects.GetProjectError>`
- **Wire**: `GET /api/projects/{id}`
- **Auth**: `workerKey`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `Project`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Projects.GetProjectError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [404] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Projects.GetProjectRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `Project` | `projectSchema` | `src/models/project.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

### listProjects

- **Signature**: `listProjects(options?: RequestOptions): ApiPromise<ProjectSummary[], ApiError>`
- **Wire**: `GET /api/projects`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `ProjectSummary[]` — a bare `application/json` array; the success type *is* the array, not a wrapper model
- **Error**: `ProofPayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `ProjectSummary` | `projectSummarySchema` | `src/models/project-summary.ts` |

