<!-- Generated file — do not edit; regenerated with the SDK. -->

# Service — operations

Accessor: `client.service` · Source: `src/resources/service.ts` · 2 operations · Request types: namespace `Service`

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `proof-pay-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### getConfig

- **Signature**: `getConfig(options?: RequestOptions): ApiPromise<ApiConfigResponse, ApiError>`
- **Wire**: `GET /api/config`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `ApiConfigResponse`
- **Error**: `ProofPayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiConfigResponse` | `apiConfigResponseSchema` | `src/models/api-config-response.ts` |

### getHealth

- **Signature**: `getHealth(options?: RequestOptions): ApiPromise<ApiHealthResponse, ApiError>`
- **Wire**: `GET /api/health`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `ApiHealthResponse`
- **Error**: `ProofPayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiHealthResponse` | `apiHealthResponseSchema` | `src/models/api-health-response.ts` |

