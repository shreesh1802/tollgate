<!-- Generated file — do not edit; regenerated with the SDK. -->

# Verification — operations

Accessor: `client.verification` · Source: `src/resources/verification.ts` · 2 operations · Request and error types: namespace `Verification`

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `proof-pay-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### decideSubmission

- **Signature**: `decideSubmission(request: Verification.DecideSubmissionRequest, options?: RequestOptions): ApiPromise<ApiVerifyResponse, Verification.DecideSubmissionError>`
- **Wire**: `POST /api/verify/{projectId}/{submissionId}`
- **Auth**: `verifierKey`
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `ApiVerifyResponse`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Verification.DecideSubmissionError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [400] `Error` · `"error2"` [401] `Error` · `"error3"` [409] `Error` · `"error4"` [502] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Verification.DecideSubmissionRequest` (3):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `projectId` | `path` | `string` | yes |
| `submissionId` | `path` | `string` | yes |
| `body` | `body` | `ApiVerifyRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiVerifyRequest` | `apiVerifyRequestSchema` | `src/models/api-verify-request.ts` |
| `ApiVerifyResponse` | `apiVerifyResponseSchema` | `src/models/api-verify-response.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

### getVerifierQueue

- **Signature**: `getVerifierQueue(options?: RequestOptions): ApiPromise<QueueItem[], Verification.GetVerifierQueueError>`
- **Wire**: `GET /api/verify/queue`
- **Auth**: `verifierKey`
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `QueueItem[]` — a bare `application/json` array; the success type *is* the array, not a wrapper model
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Verification.GetVerifierQueueError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [401] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

| Type | Schema value | Source |
| --- | --- | --- |
| `QueueItem` | `queueItemSchema` | `src/models/queue-item.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

