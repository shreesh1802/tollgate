<!-- Generated file — do not edit; regenerated with the SDK. -->

# Evidence — operations

Accessor: `client.evidence` · Source: `src/resources/evidence.ts` · 2 operations · Request and error types: namespace `Evidence`

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `proof-pay-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### getEvidenceImage

- **Signature**: `getEvidenceImage(request: Evidence.GetEvidenceImageRequest, options?: RequestOptions): ApiPromise<undefined, Evidence.GetEvidenceImageError>`
- **Wire**: `GET /api/images/{projectId}/{subId}`
- **Auth**: any of `workerKey`, `verifierKey` — the first one configured is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Evidence.GetEvidenceImageError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [403] `Error` · `"error2"` [404] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Evidence.GetEvidenceImageRequest` (2):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `projectId` | `path` | `string` | yes |
| `subId` | `path` | `string` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `Error` | `errorSchema` | `src/models/error.ts` |

### submitEvidence

- **Signature**: `submitEvidence(request: Evidence.SubmitEvidenceRequest, options?: RequestOptions): ApiPromise<SubmissionResult, Evidence.SubmitEvidenceError>`
- **Wire**: `POST /api/projects/{id}/stages/{stageId}/submissions`
- **Auth**: `workerKey`
- **Request body**: `application/json` — the `body` field, a bare top-level JSON map with no fixed keys
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `SubmissionResult`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Evidence.SubmitEvidenceError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [400] `Error` · `"error2"` [403] `Error` · `"error3"` [404] `Error` · `"error4"` [409] `Error` · `"error5"` [413] `Error` · `"error6"` [415] `Error` · `"error7"` [429] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Evidence.SubmitEvidenceRequest` (6):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |
| `stageId` | `path` | `string` | yes |
| `demoCode` | `query` | `string` | no |
| `demoMatch` | `query` | `string` | no |
| `demoFlags` | `query` | `string` | no |
| `body` | `body` | `Record<string, unknown>` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `SubmissionResult` | `submissionResultSchema` | `src/models/submission-result.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

