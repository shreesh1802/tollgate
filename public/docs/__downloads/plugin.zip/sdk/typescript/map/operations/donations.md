<!-- Generated file — do not edit; regenerated with the SDK. -->

# Donations — operations

Accessor: `client.donations` · Source: `src/resources/donations.ts` · 2 operations · Request and error types: namespace `Donations`

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `proof-pay-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### createDonation

- **Signature**: `createDonation(request: Donations.CreateDonationRequest, options?: RequestOptions): ApiPromise<ApiProjectsDonationsResponse, Donations.CreateDonationError>`
- **Wire**: `POST /api/projects/{id}/donations`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `ApiProjectsDonationsResponse`
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Donations.CreateDonationError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error"` [400] `Error` · `"error2"` [404] `Error` · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Donations.CreateDonationRequest` (2):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `id` | `path` | `string` | yes |
| `body` | `body` | `ApiProjectsDonationsRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiProjectsDonationsRequest` | `apiProjectsDonationsRequestSchema` | `src/models/api-projects-donations-request.ts` |
| `ApiProjectsDonationsResponse` | `apiProjectsDonationsResponseSchema` | `src/models/api-projects-donations-response.ts` |
| `Error` | `errorSchema` | `src/models/error.ts` |

### donationReturn

- **Signature**: `donationReturn(request: Donations.DonationReturnRequest, options?: RequestOptions): ApiPromise<undefined, Donations.DonationReturnError>`
- **Wire**: `GET /api/donate/return`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `undefined` — the operation resolves to nothing
- **Error**: `ProofPayApiError` with `kind: "api"`, an instance of `Donations.DonationReturnError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error302"` [302] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `Donations.DonationReturnRequest` (3):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `project` | `query` | `string` | yes |
| `donation` | `query` | `string` | yes |
| `token` | `query` | `string` | yes |

