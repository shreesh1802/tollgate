# Reference

**Parsed** endpoints return the typed payload and raise `ApiError` on a documented non-2xx. For the raw endpoints, see [Raw API Reference](raw-api-reference.md).

> Source: [ProofPayApiClient](proof_pay_api/client.py)

## Donations

> Source: [Donations](proof_pay_api/apis/donations.py)

<details>
<summary><code>def create_donation(id_: str, body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiProjectsDonationsResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and
is only reserved. On the sandbox, send the donor to `approveUrl` to approve it; they are
then returned to the site and the reservation is confirmed. In mock mode there is no
approval step and the donation is confirmed immediately.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.donations.create_donation("P1", ApiProjectsDonationsRequest(donor="Asha", amount=25))
    # TODO: Handle 'response' of type ApiProjectsDonationsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type CreateDonationErrorBody
```

**Async**

```python
try:
    response = await async_client.donations.create_donation("P1", ApiProjectsDonationsRequest(donor="Asha", amount=25))
    # TODO: Handle 'response' of type ApiProjectsDonationsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type CreateDonationErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Project id. |
| <code>body</code> | <code>[ApiProjectsDonationsRequest](proof_pay_api/models/api_projects_donations_request.py) \| [ApiProjectsDonationsRequestDict](proof_pay_api/models/api_projects_donations_request.py)</code> | Who is donating and how much. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiProjectsDonationsResponse](proof_pay_api/models/api_projects_donations_response.py)</code> -- Donation created.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[CreateDonationErrorBody](proof_pay_api/errors/create_donation_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 404 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def donation_return(project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

PayPal sends the donor's browser here after approval with `?token=<order id>`. It confirms
the reservation and redirects back to the site. This is not meant to be called by an API client.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.donations.donation_return("P1", "D1", "5O190127")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    await async_client.donations.donation_return("P1", "D1", "5O190127")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>project</code> | <code>str</code> | Project id. |
| <code>donation</code> | <code>str</code> | Donation id. |
| <code>token</code> | <code>str</code> | The PayPal order id. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[RawError](proof_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Evidence

> Source: [Evidence](proof_pay_api/apis/evidence.py)

<details>
<summary><code>def get_evidence_image(project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None) -> None</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Public only after the submission has released funds. Before that, the worker or verifier key is required.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    client.evidence.get_evidence_image("P1", "S1-1")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetEvidenceImageErrorBody
```

**Async**

```python
try:
    await async_client.evidence.get_evidence_image("P1", "S1-1")
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetEvidenceImageErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>project_id</code> | <code>str</code> | Project id. |
| <code>sub_id</code> | <code>str</code> | Submission id. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: No content

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[GetEvidenceImageErrorBody](proof_pay_api/errors/get_evidence_image_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 403, 404 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def submit_evidence(id_: str, stage_id: str, body: Any, *, demo_code: str | None = None, demo_match: str | None = None, demo_flags: str | None = None, request_options: RequestOptionsOrDict | None = None) -> SubmissionResult</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates,
location and time from the photo's metadata, and that the one-time code is visible, then
asks two independent AI reviewers. The deterministic gate decides: RELEASE, RESUBMIT,
HOLD (a human decides) or BLOCK. On RELEASE each donor's share is captured and the worker
is paid.

On a demo server with simulated reviewers, `demoCode`, `demoMatch` and `demoFlags` steer
the simulated reviewers; they are ignored when real reviewers are used.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.evidence.submit_evidence(
        "P1", "S1", {}, demo_code="demoCode", demo_match="0", demo_flags="demoFlags"
    )
    # TODO: Handle 'response' of type SubmissionResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type SubmitEvidenceErrorBody
```

**Async**

```python
try:
    response = await async_client.evidence.submit_evidence(
        "P1", "S1", {}, demo_code="demoCode", demo_match="0", demo_flags="demoFlags"
    )
    # TODO: Handle 'response' of type SubmissionResult
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type SubmitEvidenceErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Project id. |
| <code>stage_id</code> | <code>str</code> | Stage id within the project. |
| <code>body</code> | <code>Any</code> | The raw photo bytes (JPEG or PNG). |
| <code>demo_code</code> | <code>str \| None</code> | Simulated reviewers only. The code they report seeing.<br>**Default**: <code>None</code> |
| <code>demo_match</code> | <code>str \| None</code> | Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match the stage; any other value means it matches.<br>**Default**: <code>None</code> |
| <code>demo_flags</code> | <code>str \| None</code> | Simulated reviewers only. Comma-separated suspicion flags.<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[SubmissionResult](proof_pay_api/models/submission_result.py)</code> -- The decision for this submission.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[SubmitEvidenceErrorBody](proof_pay_api/errors/submit_evidence_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 403, 404, 409, 413, 415, 429 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

## Projects

> Source: [Projects](proof_pay_api/apis/projects.py)

<details>
<summary><code>def create_project(body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiProjectsResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Stage percentages must add up to 100. Each stage has a time window in which its evidence
must be photographed. The response contains the worker key; keep it, it is shown once.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.projects.create_project(
        NewProject(
            title="Repair the village hand pump",
            worker=Worker(name="Ravi Kumar", email="ravi@example.com"),
            site=Site(lat=12.9716, lon=77.5946, radius_m=150),
            stages=[
                NewStage(
                    title="Repair the village hand pump",
                    spec="The new pump head is installed and bolted to the base.",
                    pct=40,
                    window=TimeWindow(
                        from_=datetime(2026, 11, 1, 0, 0, 0, tzinfo=timezone.utc),
                        to=datetime(2026, 11, 30, 23, 59, 59, tzinfo=timezone.utc),
                    ),
                ),
            ],
        ),
    )
    # TODO: Handle 'response' of type ApiProjectsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type CreateProjectErrorBody
```

**Async**

```python
try:
    response = await async_client.projects.create_project(
        NewProject(
            title="Repair the village hand pump",
            worker=Worker(name="Ravi Kumar", email="ravi@example.com"),
            site=Site(lat=12.9716, lon=77.5946, radius_m=150),
            stages=[
                NewStage(
                    title="Repair the village hand pump",
                    spec="The new pump head is installed and bolted to the base.",
                    pct=40,
                    window=TimeWindow(
                        from_=datetime(2026, 11, 1, 0, 0, 0, tzinfo=timezone.utc),
                        to=datetime(2026, 11, 30, 23, 59, 59, tzinfo=timezone.utc),
                    ),
                ),
            ],
        ),
    )
    # TODO: Handle 'response' of type ApiProjectsResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type CreateProjectErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[NewProject](proof_pay_api/models/new_project.py) \| [NewProjectDict](proof_pay_api/models/new_project.py)</code> | The project to create. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiProjectsResponse](proof_pay_api/models/api_projects_response.py)</code> -- Project created.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[CreateProjectErrorBody](proof_pay_api/errors/create_project_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 401, 429 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_audit_log(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> ApiProjectsAuditResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.projects.get_audit_log("P1")
    # TODO: Handle 'response' of type ApiProjectsAuditResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetAuditLogErrorBody
```

**Async**

```python
try:
    response = await async_client.projects.get_audit_log("P1")
    # TODO: Handle 'response' of type ApiProjectsAuditResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetAuditLogErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Project id. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiProjectsAuditResponse](proof_pay_api/models/api_projects_audit_response.py)</code> -- The audit entries and the result of verifying the chain.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[GetAuditLogErrorBody](proof_pay_api/errors/get_audit_log_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_project(id_: str, *, request_options: RequestOptionsOrDict | None = None) -> Project</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The public view: donations, totals, stages and each stage's submissions. Send
`X-Worker-Key` to also receive the one-time code of the active stage.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.projects.get_project("P1")
    # TODO: Handle 'response' of type Project
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetProjectErrorBody
```

**Async**

```python
try:
    response = await async_client.projects.get_project("P1")
    # TODO: Handle 'response' of type Project
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetProjectErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>id_</code> | <code>str</code> | Project id. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Project](proof_pay_api/models/project.py)</code> -- The project.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[GetProjectErrorBody](proof_pay_api/errors/get_project_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 404 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def list_projects(*, request_options: RequestOptionsOrDict | None = None) -> list[ProjectSummary]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Also refreshes any payouts that PayPal has accepted but not yet settled.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.projects.list_projects()
    # TODO: Handle 'response' of type list[ProjectSummary]
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.projects.list_projects()
    # TODO: Handle 'response' of type list[ProjectSummary]
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>list&#91;[ProjectSummary](proof_pay_api/models/project_summary.py)&#93;</code> -- Every project, in short form.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[RawError](proof_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Service

> Source: [Service](proof_pay_api/apis/service.py)

<details>
<summary><code>def get_config(*, request_options: RequestOptionsOrDict | None = None) -> ApiConfigResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size limit.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.service.get_config()
    # TODO: Handle 'response' of type ApiConfigResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.service.get_config()
    # TODO: Handle 'response' of type ApiConfigResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiConfigResponse](proof_pay_api/models/api_config_response.py)</code> -- Server configuration.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[RawError](proof_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_health(*, request_options: RequestOptionsOrDict | None = None) -> ApiHealthResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

`uptimeSeconds` lets an operator tell a restarting process from a routing problem.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.service.get_health()
    # TODO: Handle 'response' of type ApiHealthResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.service.get_health()
    # TODO: Handle 'response' of type ApiHealthResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiHealthResponse](proof_pay_api/models/api_health_response.py)</code> -- The server is up.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[RawError](proof_pay_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Verification

> Source: [Verification](proof_pay_api/apis/verification.py)

<details>
<summary><code>def decide_submission(project_id: str, submission_id: str, body: ApiVerifyRequest | ApiVerifyRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiVerifyResponse</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Approval is bound to the evidence the verifier saw: send the `evidenceHash` from the queue
item. If the evidence changed since, the call fails with 409 and nothing is released.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.verification.decide_submission(
        "P1", "S1-1", ApiVerifyRequest(decision=Decision1.APPROVE, evidence_hash="evidenceHash")
    )
    # TODO: Handle 'response' of type ApiVerifyResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type DecideSubmissionErrorBody
```

**Async**

```python
try:
    response = await async_client.verification.decide_submission(
        "P1", "S1-1", ApiVerifyRequest(decision=Decision1.APPROVE, evidence_hash="evidenceHash")
    )
    # TODO: Handle 'response' of type ApiVerifyResponse
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type DecideSubmissionErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>project_id</code> | <code>str</code> | Project id. |
| <code>submission_id</code> | <code>str</code> | Submission id from the verifier queue. |
| <code>body</code> | <code>[ApiVerifyRequest](proof_pay_api/models/api_verify_request.py) \| [ApiVerifyRequestDict](proof_pay_api/models/api_verify_request.py)</code> | The verifier decision. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ApiVerifyResponse](proof_pay_api/models/api_verify_response.py)</code> -- The submission's new status.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[DecideSubmissionErrorBody](proof_pay_api/errors/decide_submission_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 400, 401, 409, 502 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_verifier_queue(*, request_options: RequestOptionsOrDict | None = None) -> list[QueueItem]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Submissions the gate held for review, and ones whose payment release failed and needs a retry.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.verification.get_verifier_queue()
    # TODO: Handle 'response' of type list[QueueItem]
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetVerifierQueueErrorBody
```

**Async**

```python
try:
    response = await async_client.verification.get_verifier_queue()
    # TODO: Handle 'response' of type list[QueueItem]
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type GetVerifierQueueErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](proof_pay_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>list&#91;[QueueItem](proof_pay_api/models/queue_item.py)&#93;</code> -- The queue.

**OnError**: <code>[ApiError](proof_pay_api/core/exceptions.py)&#91;[GetVerifierQueueErrorBody](proof_pay_api/errors/get_verifier_queue_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[Error](proof_pay_api/models/error.py)</code> |
| anything unmapped | <code>[RawError](proof_pay_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

