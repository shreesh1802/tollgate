from __future__ import annotations

from typing import Any

from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .chain import Chain, ChainDict


class ApiProjectsAuditResponse(SdkBaseModel):
    """The get audit log object."""

    chain: Chain
    """Result of re-computing the hash chain."""

    entries: list[Any]
    """The entries."""


class ApiProjectsAuditResponseDict(TypedDict):
    chain: ChainDict
    entries: list[Any]
