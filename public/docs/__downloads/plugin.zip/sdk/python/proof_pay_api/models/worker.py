from __future__ import annotations

from pydantic import EmailStr
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class Worker(SdkBaseModel):
    """The person who does the work and gets paid."""

    name: str
    """Full name."""

    email: EmailStr
    """The PayPal account that gets paid. Never published."""


class WorkerDict(TypedDict):
    name: str
    email: EmailStr
