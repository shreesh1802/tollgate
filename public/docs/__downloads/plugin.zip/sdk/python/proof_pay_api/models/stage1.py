from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Stage1(SdkBaseModel):
    """The stage this item belongs to."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    title: Optional[str] = UNSET
    """Short human-readable title."""

    spec: Optional[str] = UNSET
    """What the photo must show for this stage. The AI reviewers judge against this text."""


class Stage1Dict(TypedDict):
    id: NotRequired[str]
    title: NotRequired[str]
    spec: NotRequired[str]
