from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Payout(SdkBaseModel):
    """The PayPal payout to the worker for a stage. PayPal settles it after accepting it."""

    amount: Optional[str] = UNSET
    """Amount in the project currency."""

    status: Optional[str] = UNSET
    """PayPal's own payout status (for example PENDING or SUCCESS)."""


class PayoutDict(TypedDict):
    amount: NotRequired[str]
    status: NotRequired[str]
