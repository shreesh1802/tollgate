from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .check import Check, CheckDict
from .enums.decision import DecisionOrStr
from .enums.submission_status import SubmissionStatusOrStr
from .release import Release, ReleaseDict
from .review import Review, ReviewDict


class SubmissionResult(SdkBaseModel):
    """The submission result object."""

    decision: Optional[DecisionOrStr] = UNSET
    """The decision object."""

    status: Optional[SubmissionStatusOrStr] = UNSET
    """The submission status object."""

    submission_id: Optional[str] = Field(default=UNSET, alias="submissionId")
    """Id of the submission."""

    reasons: Optional[list[Any]] = UNSET
    """Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing."""

    checks: Optional[list[Check]] = UNSET
    """Results of the deterministic checks."""

    reviews: Optional[list[Review]] = UNSET
    """Opinions of the two independent AI reviewers."""

    release: Optional[Release] = UNSET
    """The release object."""


class SubmissionResultDict(TypedDict):
    decision: NotRequired[DecisionOrStr]
    status: NotRequired[SubmissionStatusOrStr]
    submission_id: NotRequired[str]
    reasons: NotRequired[list[Any]]
    checks: NotRequired[list[CheckDict]]
    reviews: NotRequired[list[ReviewDict]]
    release: NotRequired[ReleaseDict]
