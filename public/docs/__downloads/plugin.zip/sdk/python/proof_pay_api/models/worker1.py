from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Worker1(SdkBaseModel):
    """The person who does the work and gets paid."""

    name: Optional[str] = UNSET
    """Full name."""


class Worker1Dict(TypedDict):
    name: NotRequired[str]
