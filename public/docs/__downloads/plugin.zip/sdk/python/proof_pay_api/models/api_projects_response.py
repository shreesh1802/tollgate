from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiProjectsResponse(SdkBaseModel):
    """The create project object."""

    id: str
    """The id."""

    worker_key: str = Field(alias="workerKey")
    """The worker key."""

    worker_link: str = Field(alias="workerLink")
    """A link that opens the worker page already signed in."""


class ApiProjectsResponseDict(TypedDict):
    id: str
    worker_key: str
    worker_link: str
