from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .payout import Payout, PayoutDict


class Release(SdkBaseModel):
    """The release object."""

    ok: Optional[bool] = UNSET
    """Whether the operation succeeded."""

    reason: Optional[str] = UNSET
    """Why it failed, if it did."""

    payout: Optional[Payout] = UNSET
    """The PayPal payout to the worker for a stage. PayPal settles it after accepting it."""

    captures: Optional[list[Any]] = UNSET
    """Per-donor captures made for this release."""


class ReleaseDict(TypedDict):
    ok: NotRequired[bool]
    reason: NotRequired[str]
    payout: NotRequired[PayoutDict]
    captures: NotRequired[list[Any]]
