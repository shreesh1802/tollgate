from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class Site(SdkBaseModel):
    """The site object."""

    lat: float
    """Latitude of the job site in degrees."""

    lon: float
    """Longitude of the job site in degrees."""

    radius_m: float = Field(alias="radiusM")
    """Photos must be taken within this many metres."""


class SiteDict(TypedDict):
    lat: float
    lon: float
    radius_m: float
