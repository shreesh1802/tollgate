from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.id import IdOrStr
from .enums.status import StatusOrStr


class Check(SdkBaseModel):
    """The check object."""

    id: Optional[IdOrStr] = UNSET
    """Unique identifier."""

    status: Optional[StatusOrStr] = UNSET
    """Current state."""

    detail: Optional[str] = UNSET
    """Explanation of the result."""


class CheckDict(TypedDict):
    id: NotRequired[IdOrStr]
    status: NotRequired[StatusOrStr]
    detail: NotRequired[str]
