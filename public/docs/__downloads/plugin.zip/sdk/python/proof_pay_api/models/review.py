from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel


class Review(SdkBaseModel):
    """One independent AI reviewer's structured opinion. It advises; it never decides."""

    reviewer: Optional[str] = UNSET
    """Which reviewer produced this opinion."""

    matches_spec: Optional[bool] = Field(default=UNSET, alias="matchesSpec")
    """Whether the photo shows what the stage requires."""

    confidence: Optional[float] = UNSET
    """How sure the reviewer is, from 0 to 1."""

    observations: Optional[str] = UNSET
    """What the reviewer saw, in plain words."""

    visible_code: OptionalNullable[str] = Field(default=UNSET, alias="visibleCode")
    """The one-time code the reviewer read in the photo, or null."""

    suspicion: Optional[list[str]] = UNSET
    """Flags raised about the photo, such as screen-photo."""

    text_in_image: OptionalNullable[str] = Field(default=UNSET, alias="textInImage")
    """Text read out of the photo. Treated as data, never as instructions."""

    error: Optional[str] = UNSET
    """What went wrong, in plain words."""


class ReviewDict(TypedDict):
    reviewer: NotRequired[str]
    matches_spec: NotRequired[bool]
    confidence: NotRequired[float]
    observations: NotRequired[str]
    visible_code: NotRequired[str | None]
    suspicion: NotRequired[list[str]]
    text_in_image: NotRequired[str | None]
    error: NotRequired[str]
