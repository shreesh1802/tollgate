from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, RFC3339DateTime, SdkBaseModel
from .donation import Donation, DonationDict
from .site import Site, SiteDict
from .stage import Stage, StageDict
from .totals import Totals, TotalsDict
from .worker1 import Worker1, Worker1Dict


class Project(SdkBaseModel):
    """The project object."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    title: Optional[str] = UNSET
    """Short human-readable title."""

    started_at: OptionalNullable[RFC3339DateTime] = Field(default=UNSET, alias="startedAt")
    """When the project was created (ISO 8601, UTC)."""

    currency: Optional[str] = UNSET
    """ISO 4217 currency code of every amount in the project."""

    worker: Optional[Worker1] = UNSET
    """The person who does the work and gets paid."""

    site: Optional[Site] = UNSET
    """The site object."""

    donations: Optional[list[Donation]] = UNSET
    """Every donation to the project."""

    totals: Optional[Totals] = UNSET
    """Amounts in the project currency. ``paid`` counts only payouts PayPal has settled."""

    hold_expires_at: OptionalNullable[RFC3339DateTime] = Field(default=UNSET, alias="holdExpiresAt")
    """When the earliest PayPal reservation lapses."""

    stages: Optional[list[Stage]] = UNSET
    """The stages of the project, in order."""


class ProjectDict(TypedDict):
    id: NotRequired[str]
    title: NotRequired[str]
    started_at: NotRequired[RFC3339DateTime | None]
    currency: NotRequired[str]
    worker: NotRequired[Worker1Dict]
    site: NotRequired[SiteDict]
    donations: NotRequired[list[DonationDict]]
    totals: NotRequired[TotalsDict]
    hold_expires_at: NotRequired[RFC3339DateTime | None]
    stages: NotRequired[list[StageDict]]
