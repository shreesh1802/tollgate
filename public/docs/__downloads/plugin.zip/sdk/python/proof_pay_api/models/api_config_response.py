from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel
from .enums.mode import ModeOrStr
from .enums.review_mode import ReviewModeOrStr


class ApiConfigResponse(SdkBaseModel):
    """The get config object."""

    mode: ModeOrStr
    """The mode."""

    review_mode: ReviewModeOrStr = Field(alias="reviewMode")
    """The review mode."""

    simulated_reviews: bool = Field(alias="simulatedReviews")
    """The simulated reviews."""

    max_upload_bytes: int = Field(alias="maxUploadBytes")
    """The max upload bytes."""

    vendors: Optional[list[str]] = UNSET
    """The vendors."""

    demo: OptionalNullable[Any] = UNSET
    """Present only on the hosted demo. Contains the demo project and role keys so a visitor can try every role."""


class ApiConfigResponseDict(TypedDict):
    mode: ModeOrStr
    review_mode: ReviewModeOrStr
    simulated_reviews: bool
    max_upload_bytes: int
    vendors: NotRequired[list[str]]
    demo: NotRequired[Any | None]
