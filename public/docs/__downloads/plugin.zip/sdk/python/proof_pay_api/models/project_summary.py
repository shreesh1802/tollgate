from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.stage_status import StageStatusOrStr
from .totals import Totals, TotalsDict


class ProjectSummary(SdkBaseModel):
    """The project summary object."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    title: Optional[str] = UNSET
    """Short human-readable title."""

    totals: Optional[Totals] = UNSET
    """Amounts in the project currency. ``paid`` counts only payouts PayPal has settled."""

    stages: Optional[list[StageStatusOrStr]] = UNSET
    """The stages of the project, in order."""


class ProjectSummaryDict(TypedDict):
    id: NotRequired[str]
    title: NotRequired[str]
    totals: NotRequired[TotalsDict]
    stages: NotRequired[list[StageStatusOrStr]]
