from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiProjectsDonationsRequest(SdkBaseModel):
    """The create donation object."""

    donor: str
    """The donor."""

    amount: float
    """The amount."""


class ApiProjectsDonationsRequestDict(TypedDict):
    donor: str
    amount: float
