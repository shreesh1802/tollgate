from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, RFC3339DateTime, SdkBaseModel
from .enums.stage_status import StageStatusOrStr
from .release import Release, ReleaseDict
from .submission_summary import SubmissionSummary, SubmissionSummaryDict
from .time_window import TimeWindow, TimeWindowDict


class Stage(SdkBaseModel):
    """The stage object."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    index: Optional[int] = UNSET
    """Position of the stage, starting at 0."""

    title: Optional[str] = UNSET
    """Short human-readable title."""

    spec: Optional[str] = UNSET
    """What the photo must show for this stage. The AI reviewers judge against this text."""

    pct: Optional[int] = UNSET
    """Share of the total released at this stage, as a whole percent. All stages sum to 100."""

    window: Optional[TimeWindow] = UNSET
    """The time window object."""

    status: Optional[StageStatusOrStr] = UNSET
    """The stage status object."""

    release: Optional[Release] = UNSET
    """The release object."""

    released_at: OptionalNullable[RFC3339DateTime] = Field(default=UNSET, alias="releasedAt")
    """When the stage payment was released (ISO 8601, UTC)."""

    code: Optional[str] = UNSET
    """The one-time code to write on paper in the photo. Only returned to the worker, only while the stage is ACTIVE."""

    submissions: Optional[list[SubmissionSummary]] = UNSET
    """Evidence uploads for this stage."""


class StageDict(TypedDict):
    id: NotRequired[str]
    index: NotRequired[int]
    title: NotRequired[str]
    spec: NotRequired[str]
    pct: NotRequired[int]
    window: NotRequired[TimeWindowDict]
    status: NotRequired[StageStatusOrStr]
    release: NotRequired[ReleaseDict]
    released_at: NotRequired[RFC3339DateTime | None]
    code: NotRequired[str]
    submissions: NotRequired[list[SubmissionSummaryDict]]
