from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class SubmissionStatus(str, Enum):
    """The submission status object."""

    RECEIVED = "RECEIVED"
    RELEASED = "RELEASED"
    PENDING_REVIEW = "PENDING_REVIEW"
    RESUBMIT = "RESUBMIT"
    BLOCKED = "BLOCKED"
    REJECTED = "REJECTED"
    RELEASE_FAILED = "RELEASE_FAILED"

    __str__ = str.__str__


SubmissionStatusOrStr: TypeAlias = Annotated[SubmissionStatus | str, open_enum_validator(SubmissionStatus)]
