from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ErrorError(SdkBaseModel):
    """The error object."""

    error: str
    """What went wrong, in plain words."""


class ErrorErrorDict(TypedDict):
    error: str
