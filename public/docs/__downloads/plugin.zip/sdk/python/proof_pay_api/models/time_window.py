from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import RFC3339DateTime, SdkBaseModel


class TimeWindow(SdkBaseModel):
    """The time window object."""

    from_: RFC3339DateTime = Field(alias="from")
    """Start of the window (ISO 8601)."""

    to: RFC3339DateTime
    """End of the window (ISO 8601)."""


class TimeWindowDict(TypedDict):
    from_: RFC3339DateTime
    to: RFC3339DateTime
