from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class DonationStatus(str, Enum):
    """AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED = not approved."""

    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    CONFIRMED = "CONFIRMED"
    FAILED = "FAILED"

    __str__ = str.__str__


DonationStatusOrStr: TypeAlias = Annotated[DonationStatus | str, open_enum_validator(DonationStatus)]
