from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.submission_status import SubmissionStatusOrStr
from .release import Release, ReleaseDict


class ApiVerifyResponse(SdkBaseModel):
    """The decide submission object."""

    status: SubmissionStatusOrStr
    """The submission status object."""

    release: Optional[Release] = UNSET
    """The release object."""


class ApiVerifyResponseDict(TypedDict):
    status: SubmissionStatusOrStr
    release: NotRequired[ReleaseDict]
