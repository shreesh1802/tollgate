from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .new_stage import NewStage, NewStageDict
from .site import Site, SiteDict
from .worker import Worker, WorkerDict


class NewProject(SdkBaseModel):
    """The new project object."""

    title: str
    """Short human-readable title."""

    worker: Worker
    """The person who does the work and gets paid."""

    site: Site
    """The site object."""

    stages: list[NewStage]
    """The stages of the project, in order."""


class NewProjectDict(TypedDict):
    title: str
    worker: WorkerDict
    site: SiteDict
    stages: list[NewStageDict]
