from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiHealthResponse(SdkBaseModel):
    """The get health object."""

    ok: bool
    """The ok."""

    uptime_seconds: int = Field(alias="uptimeSeconds")
    """The uptime seconds."""


class ApiHealthResponseDict(TypedDict):
    ok: bool
    uptime_seconds: int
