from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.donation_status import DonationStatusOrStr


class Donation(SdkBaseModel):
    """The donation object."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    donor: Optional[str] = UNSET
    """Display name of the donor."""

    amount: Optional[float] = UNSET
    """Amount in the project currency."""

    status: Optional[DonationStatusOrStr] = UNSET
    """AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED = not approved."""

    released: Optional[str] = UNSET
    """How much of this donation has been captured so far."""


class DonationDict(TypedDict):
    id: NotRequired[str]
    donor: NotRequired[str]
    amount: NotRequired[float]
    status: NotRequired[DonationStatusOrStr]
    released: NotRequired[str]
