from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .enums.decision1 import Decision1OrStr


class ApiVerifyRequest(SdkBaseModel):
    """The decide submission object."""

    decision: Decision1OrStr
    """The decision."""

    evidence_hash: Optional[str] = Field(default=UNSET, alias="evidenceHash")
    """The hash from the queue item. Required to approve."""


class ApiVerifyRequestDict(TypedDict):
    decision: Decision1OrStr
    evidence_hash: NotRequired[str]
