from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Chain(SdkBaseModel):
    """Result of re-computing the hash chain."""

    ok: Optional[bool] = UNSET
    """The ok."""


class ChainDict(TypedDict):
    ok: NotRequired[bool]
