from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel
from .stage1 import Stage1, Stage1Dict
from .submission import Submission, SubmissionDict


class QueueItem(SdkBaseModel):
    """The queue item object."""

    project_id: Optional[str] = Field(default=UNSET, alias="projectId")
    """Id of the project."""

    project_title: Optional[str] = Field(default=UNSET, alias="projectTitle")
    """Title of the project."""

    stage: Optional[Stage1] = UNSET
    """The stage this item belongs to."""

    submission: Optional[Submission] = UNSET
    """The submission waiting for review."""

    evidence_hash: Optional[str] = Field(default=UNSET, alias="evidenceHash")
    """Fingerprint of the evidence the verifier is approving. Send it back unchanged."""

    image_url: Optional[str] = Field(default=UNSET, alias="imageUrl")
    """Path of the evidence photo."""


class QueueItemDict(TypedDict):
    project_id: NotRequired[str]
    project_title: NotRequired[str]
    stage: NotRequired[Stage1Dict]
    submission: NotRequired[SubmissionDict]
    evidence_hash: NotRequired[str]
    image_url: NotRequired[str]
