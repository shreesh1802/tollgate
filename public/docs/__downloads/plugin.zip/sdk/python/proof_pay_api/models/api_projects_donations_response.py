from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, OptionalNullable, SdkBaseModel
from .enums.donation_status import DonationStatusOrStr


class ApiProjectsDonationsResponse(SdkBaseModel):
    """The create donation object."""

    donation_id: str = Field(alias="donationId")
    """The donation id."""

    status: DonationStatusOrStr
    """AWAITING_APPROVAL = waiting for the donor at PayPal; CONFIRMED = the money is reserved; FAILED = not approved."""

    approve_url: OptionalNullable[str] = Field(default=UNSET, alias="approveUrl")
    """Where the donor approves the reservation. Absent in mock mode."""


class ApiProjectsDonationsResponseDict(TypedDict):
    donation_id: str
    status: DonationStatusOrStr
    approve_url: NotRequired[str | None]
