from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class Id(str, Enum):
    """Unique identifier."""

    DUPLICATE = "duplicate"
    LOCATION = "location"
    TIME = "time"
    CODE = "code"

    __str__ = str.__str__


IdOrStr: TypeAlias = Annotated[Id | str, open_enum_validator(Id)]
