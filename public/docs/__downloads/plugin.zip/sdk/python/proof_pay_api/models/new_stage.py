from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .time_window import TimeWindow, TimeWindowDict


class NewStage(SdkBaseModel):
    """The new stage object."""

    title: str
    """Short human-readable title."""

    spec: str
    """What the photo must show. The AI reviewers judge against this."""

    pct: int
    """Share of the total released at this stage. All stages must sum to 100."""

    window: TimeWindow
    """The time window object."""


class NewStageDict(TypedDict):
    title: str
    spec: str
    pct: int
    window: TimeWindowDict
