from __future__ import annotations

from typing import Any

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, RFC3339DateTime, SdkBaseModel
from .check import Check, CheckDict
from .enums.submission_status import SubmissionStatusOrStr
from .review import Review, ReviewDict


class Submission(SdkBaseModel):
    """The submission waiting for review."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    status: Optional[SubmissionStatusOrStr] = UNSET
    """The submission status object."""

    release_error: OptionalNullable[str] = Field(default=UNSET, alias="releaseError")
    """Why the payment release failed, if it did."""

    received_at: Optional[RFC3339DateTime] = Field(default=UNSET, alias="receivedAt")
    """When the server received the photo (ISO 8601, UTC)."""

    facts: Optional[Any] = UNSET
    """Facts read from the photo: time, location, perceptual hash."""

    reviews: Optional[list[Review]] = UNSET
    """Opinions of the two independent AI reviewers."""

    reasons: Optional[list[Any]] = UNSET
    """Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing."""

    checks: Optional[list[Check]] = UNSET
    """Results of the deterministic checks."""


class SubmissionDict(TypedDict):
    id: NotRequired[str]
    status: NotRequired[SubmissionStatusOrStr]
    release_error: NotRequired[str | None]
    received_at: NotRequired[RFC3339DateTime]
    facts: NotRequired[Any]
    reviews: NotRequired[list[ReviewDict]]
    reasons: NotRequired[list[Any]]
    checks: NotRequired[list[CheckDict]]
