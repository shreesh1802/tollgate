from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class ReviewMode(str, Enum):
    """The review mode."""

    DEMO = "demo"
    CLAUDE = "claude"

    __str__ = str.__str__


ReviewModeOrStr: TypeAlias = Annotated[ReviewMode | str, open_enum_validator(ReviewMode)]
