from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class StageStatus(str, Enum):
    """The stage status object."""

    PENDING = "PENDING"
    ACTIVE = "ACTIVE"
    RELEASED = "RELEASED"

    __str__ = str.__str__


StageStatusOrStr: TypeAlias = Annotated[StageStatus | str, open_enum_validator(StageStatus)]
