from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Totals(SdkBaseModel):
    """Amounts in the project currency. ``paid`` counts only payouts PayPal has settled."""

    reserved: Optional[str] = UNSET
    """Total reserved on PayPal from donors, not yet taken."""

    captured: Optional[str] = UNSET
    """Total taken from donors so far."""

    paid: Optional[str] = UNSET
    """Total paid to the worker and settled by PayPal."""

    in_transit: Optional[str] = Field(default=UNSET, alias="inTransit")
    """Paid out but not yet settled by PayPal."""

    problem: Optional[str] = UNSET
    """Payouts that failed, were returned or are unclaimed."""


class TotalsDict(TypedDict):
    reserved: NotRequired[str]
    captured: NotRequired[str]
    paid: NotRequired[str]
    in_transit: NotRequired[str]
    problem: NotRequired[str]
