from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, RFC3339DateTime, SdkBaseModel
from .enums.decision import DecisionOrStr
from .enums.submission_status import SubmissionStatusOrStr


class SubmissionSummary(SdkBaseModel):
    """The submission summary object."""

    id: Optional[str] = UNSET
    """Unique identifier."""

    status: Optional[SubmissionStatusOrStr] = UNSET
    """The submission status object."""

    received_at: Optional[RFC3339DateTime] = Field(default=UNSET, alias="receivedAt")
    """When the server received the photo (ISO 8601, UTC)."""

    decision: Optional[DecisionOrStr] = UNSET
    """The decision object."""

    reasons: Optional[list[str]] = UNSET
    """Why the gate decided this way, as rule ids such as duplicate-evidence or code-missing."""


class SubmissionSummaryDict(TypedDict):
    id: NotRequired[str]
    status: NotRequired[SubmissionStatusOrStr]
    received_at: NotRequired[RFC3339DateTime]
    decision: NotRequired[DecisionOrStr]
    reasons: NotRequired[list[str]]
