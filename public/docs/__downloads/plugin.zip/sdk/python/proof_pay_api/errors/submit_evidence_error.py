from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

SubmitEvidenceErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _SubmitEvidenceError:
    def map(self, status_code: int, content: bytes) -> SubmitEvidenceErrorBody:
        match status_code:
            case 400 | 403 | 404 | 409 | 413 | 415 | 429:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


submit_evidence_error_mapper: Final[ErrorMapper[SubmitEvidenceErrorBody]] = _SubmitEvidenceError()
