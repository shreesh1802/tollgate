from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

CreateDonationErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _CreateDonationError:
    def map(self, status_code: int, content: bytes) -> CreateDonationErrorBody:
        match status_code:
            case 400 | 404:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


create_donation_error_mapper: Final[ErrorMapper[CreateDonationErrorBody]] = _CreateDonationError()
