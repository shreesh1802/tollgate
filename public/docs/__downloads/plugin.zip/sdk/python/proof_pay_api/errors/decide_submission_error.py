from __future__ import annotations

from dataclasses import dataclass
from typing import Final, TypeAlias

from ..core import ErrorMapper, RawError, decode_json
from ..models.error import Error

DecideSubmissionErrorBody: TypeAlias = Error | RawError


@dataclass(frozen=True, slots=True)
class _DecideSubmissionError:
    def map(self, status_code: int, content: bytes) -> DecideSubmissionErrorBody:
        match status_code:
            case 400 | 401 | 409 | 502:
                return decode_json[Error](content)
            case _:
                return RawError(status_code, content)


decide_submission_error_mapper: Final[ErrorMapper[DecideSubmissionErrorBody]] = _DecideSubmissionError()
