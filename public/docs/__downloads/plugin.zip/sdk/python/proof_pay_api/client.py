from __future__ import annotations

from functools import cached_property
from types import TracebackType

from typing_extensions import Self

from .apis.donations import Donations
from .apis.evidence import Evidence
from .apis.projects import Projects
from .apis.service import Service
from .apis.verification import Verification
from .auth import AuthSchemes
from .base_client import DEFAULT_TIMEOUT, BaseProofPayApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiKeyHeaderScheme,
    HttpClient,
    Httpx2Client,
    LoggingOptionsOrDict,
    RawClient,
    RetryOptionsOrDict,
    no_auth,
    param,
)
from .server.environment import Environment


class ProofPayApiClient(BaseProofPayApiClient[RawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_http_client: HttpClient | None = None,
        worker_key: str | None = None,
        verifier_key: str | None = None,
        organizer_key: str | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = RawClient(
            http_client=custom_http_client if custom_http_client is not None else Httpx2Client(timeout=timeout),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "ProofPayApiClient/1.0.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "1.0.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )
        self._auth = AuthSchemes(
            worker_key=ApiKeyHeaderScheme("X-Worker-Key", worker_key) if worker_key is not None else no_auth,
            verifier_key=ApiKeyHeaderScheme("X-Verifier-Key", verifier_key) if verifier_key is not None else no_auth,
            organizer_key=(
                ApiKeyHeaderScheme("X-Organizer-Key", organizer_key) if organizer_key is not None else no_auth
            ),
        )

    @cached_property
    def donations(self) -> Donations:
        return Donations(self._raw_client, self._server)

    @cached_property
    def evidence(self) -> Evidence:
        return Evidence(self._raw_client, self._server, self._auth)

    @cached_property
    def projects(self) -> Projects:
        return Projects(self._raw_client, self._server, self._auth)

    @cached_property
    def service(self) -> Service:
        return Service(self._raw_client, self._server)

    @cached_property
    def verification(self) -> Verification:
        return Verification(self._raw_client, self._server, self._auth)

    def close(self) -> None:
        self._raw_client.http_client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        self.close()


Client = ProofPayApiClient
