from __future__ import annotations

from functools import cached_property
from types import TracebackType

from typing_extensions import Self

from .apis.donations import AsyncDonations
from .apis.evidence import AsyncEvidence
from .apis.projects import AsyncProjects
from .apis.service import AsyncService
from .apis.verification import AsyncVerification
from .auth import AsyncAuthSchemes
from .base_client import DEFAULT_TIMEOUT, BaseProofPayApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiKeyHeaderScheme,
    AsyncHttpClient,
    AsyncHttpx2Client,
    AsyncRawClient,
    LoggingOptionsOrDict,
    RetryOptionsOrDict,
    no_auth,
    param,
)
from .server.environment import Environment


class AsyncProofPayApiClient(BaseProofPayApiClient[AsyncRawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_async_http_client: AsyncHttpClient | None = None,
        worker_key: str | None = None,
        verifier_key: str | None = None,
        organizer_key: str | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = AsyncRawClient(
            http_client=(
                custom_async_http_client if custom_async_http_client is not None else AsyncHttpx2Client(timeout=timeout)
            ),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "ProofPayApiClient/1.0.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "1.0.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )
        self._auth = AsyncAuthSchemes(
            worker_key=ApiKeyHeaderScheme("X-Worker-Key", worker_key) if worker_key is not None else no_auth,
            verifier_key=ApiKeyHeaderScheme("X-Verifier-Key", verifier_key) if verifier_key is not None else no_auth,
            organizer_key=(
                ApiKeyHeaderScheme("X-Organizer-Key", organizer_key) if organizer_key is not None else no_auth
            ),
        )

    @cached_property
    def donations(self) -> AsyncDonations:
        return AsyncDonations(self._raw_client, self._server)

    @cached_property
    def evidence(self) -> AsyncEvidence:
        return AsyncEvidence(self._raw_client, self._server, self._auth)

    @cached_property
    def projects(self) -> AsyncProjects:
        return AsyncProjects(self._raw_client, self._server, self._auth)

    @cached_property
    def service(self) -> AsyncService:
        return AsyncService(self._raw_client, self._server)

    @cached_property
    def verification(self) -> AsyncVerification:
        return AsyncVerification(self._raw_client, self._server, self._auth)

    async def aclose(self) -> None:
        await self._raw_client.http_client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        await self.aclose()


AsyncClient = AsyncProofPayApiClient
