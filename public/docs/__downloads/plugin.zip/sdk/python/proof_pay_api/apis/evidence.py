from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from ..auth import AsyncAuthSchemes, AuthSchemes
from ..core import (
    AnySchemes,
    ApiResult,
    AsyncAnySchemes,
    AsyncRawClient,
    RawClient,
    RequestOptionsOrDict,
    SecuredRawResponse,
    async_empty_response,
    async_json_decoder,
    empty_response,
    json_body,
    json_decoder,
    param,
    unwrap,
)
from ..errors.get_evidence_image_error import GetEvidenceImageErrorBody, get_evidence_image_error_mapper
from ..errors.submit_evidence_error import SubmitEvidenceErrorBody, submit_evidence_error_mapper
from ..models.submission_result import SubmissionResult
from ..server.server import Server


class Evidence:
    def __init__(self, client: RawClient, server: Server, auth: AuthSchemes) -> None:
        self._with_raw_response = EvidenceWithRawResponse(client, server, auth)

    def get_evidence_image(
        self, project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Public only after the submission has released funds. Before that, the worker or verifier key is required.

        Args:
            project_id: Project id.
            sub_id: Submission id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The photo.

        Raises:
            ApiError: The key does not allow this, or the evidence is not public yet. No such project, stage or
                submission. ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_evidence_image(project_id, sub_id, request_options=request_options))

    def submit_evidence(
        self,
        id_: str,
        stage_id: str,
        body: Any,
        *,
        demo_code: str | None = None,
        demo_match: str | None = None,
        demo_flags: str | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> SubmissionResult:
        """The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates, location and time from
        the photo's metadata, and that the one-time code is visible, then asks two independent AI reviewers. The
        deterministic gate decides: RELEASE, RESUBMIT, HOLD (a human decides) or BLOCK. On RELEASE each donor's share is
        captured and the worker is paid.

        On a demo server with simulated reviewers, ``demoCode``, ``demoMatch`` and ``demoFlags`` steer the simulated
        reviewers; they are ignored when real reviewers are used.

        Args:
            id_: Project id.
            stage_id: Stage id within the project.
            body: The raw photo bytes (JPEG or PNG).
            demo_code: Simulated reviewers only. The code they report seeing.
            demo_match: Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match
                the stage; any other value means it matches.
            demo_flags: Simulated reviewers only. Comma-separated suspicion flags.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The decision for this submission.

        Raises:
            ApiError: The request was invalid. The message says what to fix. The key does not allow this, or the
                evidence is not public yet. No such project, stage or submission. The stage is not accepting evidence
                (it is not the active stage). The upload is larger than ``maxUploadBytes``. The file is not a JPEG or
                PNG. The hourly AI review quota has been reached. ``error`` is ``Error | RawError``."""
        return unwrap(
            self._with_raw_response.submit_evidence(
                id_,
                stage_id,
                body,
                demo_code=demo_code,
                demo_match=demo_match,
                demo_flags=demo_flags,
                request_options=request_options,
            ),
        )

    @property
    def with_raw_response(self) -> EvidenceWithRawResponse:
        return self._with_raw_response


class AsyncEvidence:
    def __init__(self, client: AsyncRawClient, server: Server, auth: AsyncAuthSchemes) -> None:
        self._with_raw_response = AsyncEvidenceWithRawResponse(client, server, auth)

    async def get_evidence_image(
        self, project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """Public only after the submission has released funds. Before that, the worker or verifier key is required.

        Args:
            project_id: Project id.
            sub_id: Submission id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The photo.

        Raises:
            ApiError: The key does not allow this, or the evidence is not public yet. No such project, stage or
                submission. ``error`` is ``Error | RawError``."""
        return unwrap(
            await self._with_raw_response.get_evidence_image(project_id, sub_id, request_options=request_options)
        )

    async def submit_evidence(
        self,
        id_: str,
        stage_id: str,
        body: Any,
        *,
        demo_code: str | None = None,
        demo_match: str | None = None,
        demo_flags: str | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> SubmissionResult:
        """The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates, location and time from
        the photo's metadata, and that the one-time code is visible, then asks two independent AI reviewers. The
        deterministic gate decides: RELEASE, RESUBMIT, HOLD (a human decides) or BLOCK. On RELEASE each donor's share is
        captured and the worker is paid.

        On a demo server with simulated reviewers, ``demoCode``, ``demoMatch`` and ``demoFlags`` steer the simulated
        reviewers; they are ignored when real reviewers are used.

        Args:
            id_: Project id.
            stage_id: Stage id within the project.
            body: The raw photo bytes (JPEG or PNG).
            demo_code: Simulated reviewers only. The code they report seeing.
            demo_match: Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match
                the stage; any other value means it matches.
            demo_flags: Simulated reviewers only. Comma-separated suspicion flags.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The decision for this submission.

        Raises:
            ApiError: The request was invalid. The message says what to fix. The key does not allow this, or the
                evidence is not public yet. No such project, stage or submission. The stage is not accepting evidence
                (it is not the active stage). The upload is larger than ``maxUploadBytes``. The file is not a JPEG or
                PNG. The hourly AI review quota has been reached. ``error`` is ``Error | RawError``."""
        return unwrap(
            await self._with_raw_response.submit_evidence(
                id_,
                stage_id,
                body,
                demo_code=demo_code,
                demo_match=demo_match,
                demo_flags=demo_flags,
                request_options=request_options,
            ),
        )

    @property
    def with_raw_response(self) -> AsyncEvidenceWithRawResponse:
        return self._with_raw_response


class EvidenceWithRawResponse(SecuredRawResponse[RawClient, Server, AuthSchemes]):
    def get_evidence_image(
        self, project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, GetEvidenceImageErrorBody]:
        """Public only after the submission has released funds. Before that, the worker or verifier key is required.

        Args:
            project_id: Project id.
            sub_id: Submission id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/images/{projectId}/{subId}"),
            path_params=[param[str]("projectId", project_id), param[str]("subId", sub_id)],
            auth_scheme=AnySchemes(self._auth.worker_key, self._auth.verifier_key),
            decoder=empty_response,
            error_mapper=get_evidence_image_error_mapper,
            request_options=request_options,
        )

    def submit_evidence(
        self,
        id_: str,
        stage_id: str,
        body: Any,
        *,
        demo_code: str | None = None,
        demo_match: str | None = None,
        demo_flags: str | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[SubmissionResult, SubmitEvidenceErrorBody]:
        """The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates, location and time from
        the photo's metadata, and that the one-time code is visible, then asks two independent AI reviewers. The
        deterministic gate decides: RELEASE, RESUBMIT, HOLD (a human decides) or BLOCK. On RELEASE each donor's share is
        captured and the worker is paid.

        On a demo server with simulated reviewers, ``demoCode``, ``demoMatch`` and ``demoFlags`` steer the simulated
        reviewers; they are ignored when real reviewers are used.

        Args:
            id_: Project id.
            stage_id: Stage id within the project.
            body: The raw photo bytes (JPEG or PNG).
            demo_code: Simulated reviewers only. The code they report seeing.
            demo_match: Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match
                the stage; any other value means it matches.
            demo_flags: Simulated reviewers only. Comma-separated suspicion flags.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects/{id}/stages/{stageId}/submissions"),
            path_params=[param[str]("id", id_), param[str]("stageId", stage_id)],
            query_params=[
                param[str | None]("demoCode", demo_code),
                param[str | None]("demoMatch", demo_match),
                param[str | None]("demoFlags", demo_flags),
            ],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[Any](body),
            auth_scheme=self._auth.worker_key,
            decoder=json_decoder[SubmissionResult],
            error_mapper=submit_evidence_error_mapper,
            request_options=request_options,
        )


class AsyncEvidenceWithRawResponse(SecuredRawResponse[AsyncRawClient, Server, AsyncAuthSchemes]):
    async def get_evidence_image(
        self, project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, GetEvidenceImageErrorBody]:
        """Public only after the submission has released funds. Before that, the worker or verifier key is required.

        Args:
            project_id: Project id.
            sub_id: Submission id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/images/{projectId}/{subId}"),
            path_params=[param[str]("projectId", project_id), param[str]("subId", sub_id)],
            auth_scheme=AsyncAnySchemes(self._auth.worker_key, self._auth.verifier_key),
            decoder=async_empty_response,
            error_mapper=get_evidence_image_error_mapper,
            request_options=request_options,
        )

    async def submit_evidence(
        self,
        id_: str,
        stage_id: str,
        body: Any,
        *,
        demo_code: str | None = None,
        demo_match: str | None = None,
        demo_flags: str | None = None,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[SubmissionResult, SubmitEvidenceErrorBody]:
        """The body is the raw image (JPEG or PNG), not a form. The server checks for duplicates, location and time from
        the photo's metadata, and that the one-time code is visible, then asks two independent AI reviewers. The
        deterministic gate decides: RELEASE, RESUBMIT, HOLD (a human decides) or BLOCK. On RELEASE each donor's share is
        captured and the worker is paid.

        On a demo server with simulated reviewers, ``demoCode``, ``demoMatch`` and ``demoFlags`` steer the simulated
        reviewers; they are ignored when real reviewers are used.

        Args:
            id_: Project id.
            stage_id: Stage id within the project.
            body: The raw photo bytes (JPEG or PNG).
            demo_code: Simulated reviewers only. The code they report seeing.
            demo_match: Simulated reviewers only. Send 0 to make the simulated reviewers say the photo does not match
                the stage; any other value means it matches.
            demo_flags: Simulated reviewers only. Comma-separated suspicion flags.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects/{id}/stages/{stageId}/submissions"),
            path_params=[param[str]("id", id_), param[str]("stageId", stage_id)],
            query_params=[
                param[str | None]("demoCode", demo_code),
                param[str | None]("demoMatch", demo_match),
                param[str | None]("demoFlags", demo_flags),
            ],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[Any](body),
            auth_scheme=self._auth.worker_key,
            decoder=async_json_decoder[SubmissionResult],
            error_mapper=submit_evidence_error_mapper,
            request_options=request_options,
        )
