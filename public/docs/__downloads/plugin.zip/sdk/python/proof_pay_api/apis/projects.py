from __future__ import annotations

from uuid import UUID, uuid4

from ..auth import AsyncAuthSchemes, AuthSchemes
from ..core import (
    ApiResult,
    AsyncRawClient,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    SecuredRawResponse,
    async_json_decoder,
    json_body,
    json_decoder,
    param,
    raw_error_response,
    unwrap,
)
from ..errors.create_project_error import CreateProjectErrorBody, create_project_error_mapper
from ..errors.get_audit_log_error import GetAuditLogErrorBody, get_audit_log_error_mapper
from ..errors.get_project_error import GetProjectErrorBody, get_project_error_mapper
from ..models.api_projects_audit_response import ApiProjectsAuditResponse
from ..models.api_projects_response import ApiProjectsResponse
from ..models.new_project import NewProject, NewProjectDict
from ..models.project import Project
from ..models.project_summary import ProjectSummary
from ..server.server import Server


class Projects:
    def __init__(self, client: RawClient, server: Server, auth: AuthSchemes) -> None:
        self._with_raw_response = ProjectsWithRawResponse(client, server, auth)

    def create_project(
        self, body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiProjectsResponse:
        """Stage percentages must add up to 100. Each stage has a time window in which its evidence must be
        photographed. The response contains the worker key; keep it, it is shown once.

        Args:
            body: The project to create.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Project created.

        Raises:
            ApiError: The request was invalid. The message says what to fix. A required key is missing or wrong. The
                hosted demo has reached its project limit. ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.create_project(body, request_options=request_options))

    def get_audit_log(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiProjectsAuditResponse:
        """Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The audit entries and the result of verifying the chain.

        Raises:
            ApiError: No such project, stage or submission. ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_audit_log(id_, request_options=request_options))

    def get_project(self, id_: str, *, request_options: RequestOptionsOrDict | None = None) -> Project:
        """The public view: donations, totals, stages and each stage's submissions. Send ``X-Worker-Key`` to also
        receive the one-time code of the active stage.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The project.

        Raises:
            ApiError: No such project, stage or submission. ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_project(id_, request_options=request_options))

    def list_projects(self, *, request_options: RequestOptionsOrDict | None = None) -> list[ProjectSummary]:
        """Also refreshes any payouts that PayPal has accepted but not yet settled.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Every project, in short form.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.list_projects(request_options=request_options))

    @property
    def with_raw_response(self) -> ProjectsWithRawResponse:
        return self._with_raw_response


class AsyncProjects:
    def __init__(self, client: AsyncRawClient, server: Server, auth: AsyncAuthSchemes) -> None:
        self._with_raw_response = AsyncProjectsWithRawResponse(client, server, auth)

    async def create_project(
        self, body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiProjectsResponse:
        """Stage percentages must add up to 100. Each stage has a time window in which its evidence must be
        photographed. The response contains the worker key; keep it, it is shown once.

        Args:
            body: The project to create.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Project created.

        Raises:
            ApiError: The request was invalid. The message says what to fix. A required key is missing or wrong. The
                hosted demo has reached its project limit. ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.create_project(body, request_options=request_options))

    async def get_audit_log(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiProjectsAuditResponse:
        """Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The audit entries and the result of verifying the chain.

        Raises:
            ApiError: No such project, stage or submission. ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.get_audit_log(id_, request_options=request_options))

    async def get_project(self, id_: str, *, request_options: RequestOptionsOrDict | None = None) -> Project:
        """The public view: donations, totals, stages and each stage's submissions. Send ``X-Worker-Key`` to also
        receive the one-time code of the active stage.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The project.

        Raises:
            ApiError: No such project, stage or submission. ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.get_project(id_, request_options=request_options))

    async def list_projects(self, *, request_options: RequestOptionsOrDict | None = None) -> list[ProjectSummary]:
        """Also refreshes any payouts that PayPal has accepted but not yet settled.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Every project, in short form.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.list_projects(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncProjectsWithRawResponse:
        return self._with_raw_response


class ProjectsWithRawResponse(SecuredRawResponse[RawClient, Server, AuthSchemes]):
    def create_project(
        self, body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiProjectsResponse, CreateProjectErrorBody]:
        """Stage percentages must add up to 100. Each stage has a time window in which its evidence must be
        photographed. The response contains the worker key; keep it, it is shown once.

        Args:
            body: The project to create.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[NewProject | NewProjectDict](body),
            auth_scheme=self._auth.organizer_key,
            decoder=json_decoder[ApiProjectsResponse],
            error_mapper=create_project_error_mapper,
            request_options=request_options,
        )

    def get_audit_log(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiProjectsAuditResponse, GetAuditLogErrorBody]:
        """Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects/{id}/audit"),
            path_params=[param[str]("id", id_)],
            decoder=json_decoder[ApiProjectsAuditResponse],
            error_mapper=get_audit_log_error_mapper,
            request_options=request_options,
        )

    def get_project(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Project, GetProjectErrorBody]:
        """The public view: donations, totals, stages and each stage's submissions. Send ``X-Worker-Key`` to also
        receive the one-time code of the active stage.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects/{id}"),
            path_params=[param[str]("id", id_)],
            auth_scheme=self._auth.worker_key,
            decoder=json_decoder[Project],
            error_mapper=get_project_error_mapper,
            request_options=request_options,
        )

    def list_projects(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[list[ProjectSummary], RawError]:
        """Also refreshes any payouts that PayPal has accepted but not yet settled.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects"),
            decoder=json_decoder[list[ProjectSummary]],
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncProjectsWithRawResponse(SecuredRawResponse[AsyncRawClient, Server, AsyncAuthSchemes]):
    async def create_project(
        self, body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiProjectsResponse, CreateProjectErrorBody]:
        """Stage percentages must add up to 100. Each stage has a time window in which its evidence must be
        photographed. The response contains the worker key; keep it, it is shown once.

        Args:
            body: The project to create.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[NewProject | NewProjectDict](body),
            auth_scheme=self._auth.organizer_key,
            decoder=async_json_decoder[ApiProjectsResponse],
            error_mapper=create_project_error_mapper,
            request_options=request_options,
        )

    async def get_audit_log(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiProjectsAuditResponse, GetAuditLogErrorBody]:
        """Every decision is an entry that includes the hash of the one before it, so altering history breaks the chain.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects/{id}/audit"),
            path_params=[param[str]("id", id_)],
            decoder=async_json_decoder[ApiProjectsAuditResponse],
            error_mapper=get_audit_log_error_mapper,
            request_options=request_options,
        )

    async def get_project(
        self, id_: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Project, GetProjectErrorBody]:
        """The public view: donations, totals, stages and each stage's submissions. Send ``X-Worker-Key`` to also
        receive the one-time code of the active stage.

        Args:
            id_: Project id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects/{id}"),
            path_params=[param[str]("id", id_)],
            auth_scheme=self._auth.worker_key,
            decoder=async_json_decoder[Project],
            error_mapper=get_project_error_mapper,
            request_options=request_options,
        )

    async def list_projects(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[list[ProjectSummary], RawError]:
        """Also refreshes any payouts that PayPal has accepted but not yet settled.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/projects"),
            decoder=async_json_decoder[list[ProjectSummary]],
            error_mapper=raw_error_response,
            request_options=request_options,
        )
