from __future__ import annotations

from uuid import UUID, uuid4

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    async_empty_response,
    async_json_decoder,
    empty_response,
    json_body,
    json_decoder,
    param,
    raw_error_response,
    unwrap,
)
from ..errors.create_donation_error import CreateDonationErrorBody, create_donation_error_mapper
from ..models.api_projects_donations_request import ApiProjectsDonationsRequest, ApiProjectsDonationsRequestDict
from ..models.api_projects_donations_response import ApiProjectsDonationsResponse
from ..server.server import Server


class Donations:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = DonationsWithRawResponse(client, server)

    def create_donation(
        self,
        id_: str,
        body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiProjectsDonationsResponse:
        """Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and is only reserved. On
        the sandbox, send the donor to ``approveUrl`` to approve it; they are then returned to the site and the
        reservation is confirmed. In mock mode there is no approval step and the donation is confirmed immediately.

        Args:
            id_: Project id.
            body: Who is donating and how much.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Donation created.

        Raises:
            ApiError: The request was invalid. The message says what to fix. No such project, stage or submission.
                ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.create_donation(id_, body, request_options=request_options))

    def donation_return(
        self, project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """PayPal sends the donor's browser here after approval with ``?token=<order id>``. It confirms the reservation
        and redirects back to the site. This is not meant to be called by an API client.

        Args:
            project: Project id.
            donation: Donation id.
            token: The PayPal order id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            self._with_raw_response.donation_return(project, donation, token, request_options=request_options)
        )

    @property
    def with_raw_response(self) -> DonationsWithRawResponse:
        return self._with_raw_response


class AsyncDonations:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncDonationsWithRawResponse(client, server)

    async def create_donation(
        self,
        id_: str,
        body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiProjectsDonationsResponse:
        """Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and is only reserved. On
        the sandbox, send the donor to ``approveUrl`` to approve it; they are then returned to the site and the
        reservation is confirmed. In mock mode there is no approval step and the donation is confirmed immediately.

        Args:
            id_: Project id.
            body: Who is donating and how much.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Donation created.

        Raises:
            ApiError: The request was invalid. The message says what to fix. No such project, stage or submission.
                ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.create_donation(id_, body, request_options=request_options))

    async def donation_return(
        self, project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> None:
        """PayPal sends the donor's browser here after approval with ``?token=<order id>``. It confirms the reservation
        and redirects back to the site. This is not meant to be called by an API client.

        Args:
            project: Project id.
            donation: Donation id.
            token: The PayPal order id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(
            await self._with_raw_response.donation_return(project, donation, token, request_options=request_options)
        )

    @property
    def with_raw_response(self) -> AsyncDonationsWithRawResponse:
        return self._with_raw_response


class DonationsWithRawResponse(BaseRawResponse[RawClient, Server]):
    def create_donation(
        self,
        id_: str,
        body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiProjectsDonationsResponse, CreateDonationErrorBody]:
        """Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and is only reserved. On
        the sandbox, send the donor to ``approveUrl`` to approve it; they are then returned to the site and the
        reservation is confirmed. In mock mode there is no approval step and the donation is confirmed immediately.

        Args:
            id_: Project id.
            body: Who is donating and how much.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects/{id}/donations"),
            path_params=[param[str]("id", id_)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict](body),
            decoder=json_decoder[ApiProjectsDonationsResponse],
            error_mapper=create_donation_error_mapper,
            request_options=request_options,
        )

    def donation_return(
        self, project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal sends the donor's browser here after approval with ``?token=<order id>``. It confirms the reservation
        and redirects back to the site. This is not meant to be called by an API client.

        Args:
            project: Project id.
            donation: Donation id.
            token: The PayPal order id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/donate/return"),
            query_params=[param[str]("project", project), param[str]("donation", donation), param[str]("token", token)],
            decoder=empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncDonationsWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def create_donation(
        self,
        id_: str,
        body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiProjectsDonationsResponse, CreateDonationErrorBody]:
        """Creates a PayPal order with intent AUTHORIZE: the money stays in the donor's account and is only reserved. On
        the sandbox, send the donor to ``approveUrl`` to approve it; they are then returned to the site and the
        reservation is confirmed. In mock mode there is no approval step and the donation is confirmed immediately.

        Args:
            id_: Project id.
            body: Who is donating and how much.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/projects/{id}/donations"),
            path_params=[param[str]("id", id_)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict](body),
            decoder=async_json_decoder[ApiProjectsDonationsResponse],
            error_mapper=create_donation_error_mapper,
            request_options=request_options,
        )

    async def donation_return(
        self, project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[None, RawError]:
        """PayPal sends the donor's browser here after approval with ``?token=<order id>``. It confirms the reservation
        and redirects back to the site. This is not meant to be called by an API client.

        Args:
            project: Project id.
            donation: Donation id.
            token: The PayPal order id.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/donate/return"),
            query_params=[param[str]("project", project), param[str]("donation", donation), param[str]("token", token)],
            decoder=async_empty_response,
            error_mapper=raw_error_response,
            request_options=request_options,
        )
