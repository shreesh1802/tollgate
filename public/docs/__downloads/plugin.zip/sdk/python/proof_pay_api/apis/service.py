from __future__ import annotations

from ..core import (
    ApiResult,
    AsyncRawClient,
    BaseRawResponse,
    RawClient,
    RawError,
    RequestOptionsOrDict,
    async_json_decoder,
    json_decoder,
    raw_error_response,
    unwrap,
)
from ..models.api_config_response import ApiConfigResponse
from ..models.api_health_response import ApiHealthResponse
from ..server.server import Server


class Service:
    def __init__(self, client: RawClient, server: Server) -> None:
        self._with_raw_response = ServiceWithRawResponse(client, server)

    def get_config(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiConfigResponse:
        """Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size
        limit.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Server configuration.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.get_config(request_options=request_options))

    def get_health(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiHealthResponse:
        """``uptimeSeconds`` lets an operator tell a restarting process from a routing problem.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The server is up.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(self._with_raw_response.get_health(request_options=request_options))

    @property
    def with_raw_response(self) -> ServiceWithRawResponse:
        return self._with_raw_response


class AsyncService:
    def __init__(self, client: AsyncRawClient, server: Server) -> None:
        self._with_raw_response = AsyncServiceWithRawResponse(client, server)

    async def get_config(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiConfigResponse:
        """Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size
        limit.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            Server configuration.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.get_config(request_options=request_options))

    async def get_health(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiHealthResponse:
        """``uptimeSeconds`` lets an operator tell a restarting process from a routing problem.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The server is up.

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self._with_raw_response.get_health(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncServiceWithRawResponse:
        return self._with_raw_response


class ServiceWithRawResponse(BaseRawResponse[RawClient, Server]):
    def get_config(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiConfigResponse, RawError]:
        """Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size
        limit.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/config"),
            decoder=json_decoder[ApiConfigResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    def get_health(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiHealthResponse, RawError]:
        """``uptimeSeconds`` lets an operator tell a restarting process from a routing problem.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/health"),
            decoder=json_decoder[ApiHealthResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )


class AsyncServiceWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def get_config(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiConfigResponse, RawError]:
        """Tells a client whether payments are mock or sandbox, whether reviews are simulated, and the upload size
        limit.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/config"),
            decoder=async_json_decoder[ApiConfigResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def get_health(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[ApiHealthResponse, RawError]:
        """``uptimeSeconds`` lets an operator tell a restarting process from a routing problem.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/health"),
            decoder=async_json_decoder[ApiHealthResponse],
            error_mapper=raw_error_response,
            request_options=request_options,
        )
