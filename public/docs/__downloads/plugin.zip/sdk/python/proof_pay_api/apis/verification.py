from __future__ import annotations

from uuid import UUID, uuid4

from ..auth import AsyncAuthSchemes, AuthSchemes
from ..core import (
    ApiResult,
    AsyncRawClient,
    RawClient,
    RequestOptionsOrDict,
    SecuredRawResponse,
    async_json_decoder,
    json_body,
    json_decoder,
    param,
    unwrap,
)
from ..errors.decide_submission_error import DecideSubmissionErrorBody, decide_submission_error_mapper
from ..errors.get_verifier_queue_error import GetVerifierQueueErrorBody, get_verifier_queue_error_mapper
from ..models.api_verify_request import ApiVerifyRequest, ApiVerifyRequestDict
from ..models.api_verify_response import ApiVerifyResponse
from ..models.queue_item import QueueItem
from ..server.server import Server


class Verification:
    def __init__(self, client: RawClient, server: Server, auth: AuthSchemes) -> None:
        self._with_raw_response = VerificationWithRawResponse(client, server, auth)

    def decide_submission(
        self,
        project_id: str,
        submission_id: str,
        body: ApiVerifyRequest | ApiVerifyRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiVerifyResponse:
        """Approval is bound to the evidence the verifier saw: send the ``evidenceHash`` from the queue item. If the
        evidence changed since, the call fails with 409 and nothing is released.

        Args:
            project_id: Project id.
            submission_id: Submission id from the verifier queue.
            body: The verifier decision.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The submission's new status.

        Raises:
            ApiError: The request was invalid. The message says what to fix. A required key is missing or wrong. The
                submission is not awaiting review, or the evidence changed since it was shown. PayPal returned an error.
                Nothing was released. ``error`` is ``Error | RawError``."""
        return unwrap(
            self._with_raw_response.decide_submission(project_id, submission_id, body, request_options=request_options)
        )

    def get_verifier_queue(self, *, request_options: RequestOptionsOrDict | None = None) -> list[QueueItem]:
        """Submissions the gate held for review, and ones whose payment release failed and needs a retry.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The queue.

        Raises:
            ApiError: A required key is missing or wrong. ``error`` is ``Error | RawError``."""
        return unwrap(self._with_raw_response.get_verifier_queue(request_options=request_options))

    @property
    def with_raw_response(self) -> VerificationWithRawResponse:
        return self._with_raw_response


class AsyncVerification:
    def __init__(self, client: AsyncRawClient, server: Server, auth: AsyncAuthSchemes) -> None:
        self._with_raw_response = AsyncVerificationWithRawResponse(client, server, auth)

    async def decide_submission(
        self,
        project_id: str,
        submission_id: str,
        body: ApiVerifyRequest | ApiVerifyRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiVerifyResponse:
        """Approval is bound to the evidence the verifier saw: send the ``evidenceHash`` from the queue item. If the
        evidence changed since, the call fails with 409 and nothing is released.

        Args:
            project_id: Project id.
            submission_id: Submission id from the verifier queue.
            body: The verifier decision.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The submission's new status.

        Raises:
            ApiError: The request was invalid. The message says what to fix. A required key is missing or wrong. The
                submission is not awaiting review, or the evidence changed since it was shown. PayPal returned an error.
                Nothing was released. ``error`` is ``Error | RawError``."""
        return unwrap(
            await self._with_raw_response.decide_submission(
                project_id, submission_id, body, request_options=request_options
            ),
        )

    async def get_verifier_queue(self, *, request_options: RequestOptionsOrDict | None = None) -> list[QueueItem]:
        """Submissions the gate held for review, and ones whose payment release failed and needs a retry.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            The queue.

        Raises:
            ApiError: A required key is missing or wrong. ``error`` is ``Error | RawError``."""
        return unwrap(await self._with_raw_response.get_verifier_queue(request_options=request_options))

    @property
    def with_raw_response(self) -> AsyncVerificationWithRawResponse:
        return self._with_raw_response


class VerificationWithRawResponse(SecuredRawResponse[RawClient, Server, AuthSchemes]):
    def decide_submission(
        self,
        project_id: str,
        submission_id: str,
        body: ApiVerifyRequest | ApiVerifyRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiVerifyResponse, DecideSubmissionErrorBody]:
        """Approval is bound to the evidence the verifier saw: send the ``evidenceHash`` from the queue item. If the
        evidence changed since, the call fails with 409 and nothing is released.

        Args:
            project_id: Project id.
            submission_id: Submission id from the verifier queue.
            body: The verifier decision.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/verify/{projectId}/{submissionId}"),
            path_params=[param[str]("projectId", project_id), param[str]("submissionId", submission_id)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiVerifyRequest | ApiVerifyRequestDict](body),
            auth_scheme=self._auth.verifier_key,
            decoder=json_decoder[ApiVerifyResponse],
            error_mapper=decide_submission_error_mapper,
            request_options=request_options,
        )

    def get_verifier_queue(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[list[QueueItem], GetVerifierQueueErrorBody]:
        """Submissions the gate held for review, and ones whose payment release failed and needs a retry.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/verify/queue"),
            auth_scheme=self._auth.verifier_key,
            decoder=json_decoder[list[QueueItem]],
            error_mapper=get_verifier_queue_error_mapper,
            request_options=request_options,
        )


class AsyncVerificationWithRawResponse(SecuredRawResponse[AsyncRawClient, Server, AsyncAuthSchemes]):
    async def decide_submission(
        self,
        project_id: str,
        submission_id: str,
        body: ApiVerifyRequest | ApiVerifyRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[ApiVerifyResponse, DecideSubmissionErrorBody]:
        """Approval is bound to the evidence the verifier saw: send the ``evidenceHash`` from the queue item. If the
        evidence changed since, the call fails with 409 and nothing is released.

        Args:
            project_id: Project id.
            submission_id: Submission id from the verifier queue.
            body: The verifier decision.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/verify/{projectId}/{submissionId}"),
            path_params=[param[str]("projectId", project_id), param[str]("submissionId", submission_id)],
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiVerifyRequest | ApiVerifyRequestDict](body),
            auth_scheme=self._auth.verifier_key,
            decoder=async_json_decoder[ApiVerifyResponse],
            error_mapper=decide_submission_error_mapper,
            request_options=request_options,
        )

    async def get_verifier_queue(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[list[QueueItem], GetVerifierQueueErrorBody]:
        """Submissions the gate held for review, and ones whose payment release failed and needs a retry.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/verify/queue"),
            auth_scheme=self._auth.verifier_key,
            decoder=async_json_decoder[list[QueueItem]],
            error_mapper=get_verifier_queue_error_mapper,
            request_options=request_options,
        )
