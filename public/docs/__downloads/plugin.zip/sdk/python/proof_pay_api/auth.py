from __future__ import annotations

from dataclasses import dataclass

from .core import AsyncAuthScheme, AuthScheme


@dataclass(frozen=True, slots=True, kw_only=True)
class AuthSchemes:
    worker_key: AuthScheme
    verifier_key: AuthScheme
    organizer_key: AuthScheme


@dataclass(frozen=True, slots=True, kw_only=True)
class AsyncAuthSchemes:
    worker_key: AsyncAuthScheme
    verifier_key: AsyncAuthScheme
    organizer_key: AsyncAuthScheme
