<!-- Generated file — do not edit; regenerated with the SDK. -->

# Service — operations

Accessor: `client.service` · Source: `proof_pay_api/apis/service.py` · 2 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.service.get_config

- **Route**: `GET /api/config`
- **Signature**: `def get_config(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `ApiConfigResponse`
- **Returns (raw)**: `ApiResult[ApiConfigResponse, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiConfigResponse` | `proof_pay_api/models/api_config_response.py` |

### client.service.get_health

- **Route**: `GET /api/health`
- **Signature**: `def get_health(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `ApiHealthResponse`
- **Returns (raw)**: `ApiResult[ApiHealthResponse, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiHealthResponse` | `proof_pay_api/models/api_health_response.py` |

