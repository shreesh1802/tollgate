<!-- Generated file — do not edit; regenerated with the SDK. -->

# Projects — operations

Accessor: `client.projects` · Source: `proof_pay_api/apis/projects.py` · 4 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.projects.create_project

- **Route**: `POST /api/projects`
- **Auth**: `organizer_key`
- **Signature**: `def create_project(body: NewProject | NewProjectDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `ApiProjectsResponse`
- **Returns (raw)**: `ApiResult[ApiProjectsResponse, CreateProjectErrorBody]`
- **Error**: `CreateProjectErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 401, 429] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `NewProject` | `proof_pay_api/models/new_project.py` |
| `NewProjectDict` | `proof_pay_api/models/new_project.py` |
| `ApiProjectsResponse` | `proof_pay_api/models/api_projects_response.py` |
| `CreateProjectErrorBody` | `proof_pay_api/errors/create_project_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.projects.get_audit_log

- **Route**: `GET /api/projects/{id}/audit`
- **Signature**: `def get_audit_log(id_: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`
- **Params**: `id_` — path `id`
- **Returns (parsed)**: `ApiProjectsAuditResponse`
- **Returns (raw)**: `ApiResult[ApiProjectsAuditResponse, GetAuditLogErrorBody]`
- **Error**: `GetAuditLogErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiProjectsAuditResponse` | `proof_pay_api/models/api_projects_audit_response.py` |
| `GetAuditLogErrorBody` | `proof_pay_api/errors/get_audit_log_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.projects.get_project

- **Route**: `GET /api/projects/{id}`
- **Auth**: `worker_key`
- **Signature**: `def get_project(id_: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`
- **Params**: `id_` — path `id`
- **Returns (parsed)**: `Project`
- **Returns (raw)**: `ApiResult[Project, GetProjectErrorBody]`
- **Error**: `GetProjectErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `Project` | `proof_pay_api/models/project.py` |
| `GetProjectErrorBody` | `proof_pay_api/errors/get_project_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.projects.list_projects

- **Route**: `GET /api/projects`
- **Signature**: `def list_projects(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `list[ProjectSummary]`
- **Returns (raw)**: `ApiResult[list[ProjectSummary], RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ProjectSummary` | `proof_pay_api/models/project_summary.py` |

