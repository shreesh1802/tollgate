<!-- Generated file — do not edit; regenerated with the SDK. -->

# Donations — operations

Accessor: `client.donations` · Source: `proof_pay_api/apis/donations.py` · 2 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded, and an operation with no table mentions nothing but builtins and those.

### client.donations.create_donation

- **Route**: `POST /api/projects/{id}/donations`
- **Signature**: `def create_donation(id_: str, body: ApiProjectsDonationsRequest | ApiProjectsDonationsRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`, `body`
- **Params**: `id_` — path `id` · `body` — JSON body
- **Returns (parsed)**: `ApiProjectsDonationsResponse`
- **Returns (raw)**: `ApiResult[ApiProjectsDonationsResponse, CreateDonationErrorBody]`
- **Error**: `CreateDonationErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiProjectsDonationsRequest` | `proof_pay_api/models/api_projects_donations_request.py` |
| `ApiProjectsDonationsRequestDict` | `proof_pay_api/models/api_projects_donations_request.py` |
| `ApiProjectsDonationsResponse` | `proof_pay_api/models/api_projects_donations_response.py` |
| `CreateDonationErrorBody` | `proof_pay_api/errors/create_donation_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.donations.donation_return

- **Route**: `GET /api/donate/return`
- **Signature**: `def donation_return(project: str, donation: str, token: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `project`, `donation`, `token`
- **Params**: `project` — query · `donation` — query · `token` — query
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, RawError]`
- **Error**: `RawError` — **Case B**

