<!-- Generated file — do not edit; regenerated with the SDK. -->

# Evidence — operations

Accessor: `client.evidence` · Source: `proof_pay_api/apis/evidence.py` · 2 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.evidence.get_evidence_image

- **Route**: `GET /api/images/{projectId}/{subId}`
- **Auth**: `worker_key` OR `verifier_key`
- **Signature**: `def get_evidence_image(project_id: str, sub_id: str, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `project_id`, `sub_id`
- **Params**: `project_id` — path `projectId` · `sub_id` — path `subId`
- **Returns (parsed)**: `None`
- **Returns (raw)**: `ApiResult[None, GetEvidenceImageErrorBody]`
- **Error**: `GetEvidenceImageErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [403, 404] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `GetEvidenceImageErrorBody` | `proof_pay_api/errors/get_evidence_image_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.evidence.submit_evidence

- **Route**: `POST /api/projects/{id}/stages/{stageId}/submissions`
- **Auth**: `worker_key`
- **Signature**: `def submit_evidence(id_: str, stage_id: str, body: Any, *, demo_code: str | None = None, demo_match: str | None = None, demo_flags: str | None = None, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `id_`, `stage_id`, `body`
- **Params**: `id_` — path `id` · `stage_id` — path `stageId` · `demo_code` — query `demoCode` · `demo_match` — query `demoMatch` · `demo_flags` — query `demoFlags` · `body` — JSON body
- **Returns (parsed)**: `SubmissionResult`
- **Returns (raw)**: `ApiResult[SubmissionResult, SubmitEvidenceErrorBody]`
- **Error**: `SubmitEvidenceErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 403, 404, 409, 413, 415, 429] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `SubmissionResult` | `proof_pay_api/models/submission_result.py` |
| `SubmitEvidenceErrorBody` | `proof_pay_api/errors/submit_evidence_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

