<!-- Generated file — do not edit; regenerated with the SDK. -->

# Verification — operations

Accessor: `client.verification` · Source: `proof_pay_api/apis/verification.py` · 2 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded.

### client.verification.decide_submission

- **Route**: `POST /api/verify/{projectId}/{submissionId}`
- **Auth**: `verifier_key`
- **Signature**: `def decide_submission(project_id: str, submission_id: str, body: ApiVerifyRequest | ApiVerifyRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `project_id`, `submission_id`, `body`
- **Params**: `project_id` — path `projectId` · `submission_id` — path `submissionId` · `body` — JSON body
- **Returns (parsed)**: `ApiVerifyResponse`
- **Returns (raw)**: `ApiResult[ApiVerifyResponse, DecideSubmissionErrorBody]`
- **Error**: `DecideSubmissionErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [400, 401, 409, 502] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `ApiVerifyRequest` | `proof_pay_api/models/api_verify_request.py` |
| `ApiVerifyRequestDict` | `proof_pay_api/models/api_verify_request.py` |
| `ApiVerifyResponse` | `proof_pay_api/models/api_verify_response.py` |
| `DecideSubmissionErrorBody` | `proof_pay_api/errors/decide_submission_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

### client.verification.get_verifier_queue

- **Route**: `GET /api/verify/queue`
- **Auth**: `verifier_key`
- **Signature**: `def get_verifier_queue(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `list[QueueItem]`
- **Returns (raw)**: `ApiResult[list[QueueItem], GetVerifierQueueErrorBody]`
- **Error**: `GetVerifierQueueErrorBody` — **Case A (typed)**
- **Error arms**: `Error` [401] · `RawError` [anything unmapped]

| Type | Source |
| --- | --- |
| `QueueItem` | `proof_pay_api/models/queue_item.py` |
| `GetVerifierQueueErrorBody` | `proof_pay_api/errors/get_verifier_queue_error.py` |
| `Error` | `proof_pay_api/models/error.py` |

